from app.app import create_app
from app.models.eatery import Eatery
from app.models.review import Review
from lin.db import db
from lin.core import User, Group, Auth

import pandas as pd

eatry_infos = pd.read_csv('data/eateries.csv',encoding='utf-8')

review_df = pd.read_csv('data/review_info_cleaned.csv',encoding='utf-8')

app = create_app()
with app.app_context():
    with db.auto_commit():
        for index,row in eatry_infos.iterrows():
            eatery = Eatery()
            eatery.link = row['link']
            eatery.cuisine = row['cuisine']
            eatery.rating = row['rating']
            eatery.name = row['name']
            eatery.address = row['address']
            eatery.from_info = row['from']
            eatery.phone = row['tel']
            eatery.coordinate_lat = row['coordinate'].split(',')[0]
            eatery.coordinate_lng = row['coordinate'].split(',')[1]
            eatery.description = row['description']
            db.session.add(eatery)
            db.session.flush()
            for idx,r in (review_df[review_df.res_id == row['res_id']]).iterrows():
              review = Review()
              review.e_id = eatery.id
              review.reviewer_name = r['name']
              review.content = r['review']
              review.rating = r['rating']
              review.comments_num = r['comment']
              review.helpful_num = r['helpful']
              review.arriving_time = r['arriving time']
              review.review_time = r['review time']
              review.reported = 0
              db.session.add(review)