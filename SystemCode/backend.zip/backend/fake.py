from app.app import create_app
from app.models.book import Book
from lin.db import db
from lin.core import User, Group, Auth

app = create_app()
with app.app_context():
    with db.auto_commit():
        group = Group()
        group.name = 'eatery_owner'
        group.info = 'eatery_owner'
        db.session.add(group)

        group = Group()
        group.name = 'customer'
        group.info = 'customer'
        db.session.add(group)
        # db.session.flush()

        # user = User()
        # user.username = 'pedro'
        # user.password = '123456'
        # user.email = '123456780000@qq.com'
        # db.session.add(user)

        # auth = Auth()
        # auth.auth = '删除图书'
        # auth.module = '图书'
        # auth.group_id = group.id
        # db.session.add(auth)