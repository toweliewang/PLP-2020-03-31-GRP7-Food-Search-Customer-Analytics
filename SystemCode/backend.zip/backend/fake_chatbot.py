from app.app import create_app
from lin.db import db
from lin.core import User, Group, Auth

from app.models.entity import Entity
from app.models.phase import Phase

#entities
E001 = ["chili crab","steak","fish and chip","crab"] #dish
E002 = ["chinese","french","indian","indonesian","italian","japanese","korean","malay","mexican","peranakan","asian"] #cuisine
E003 = ["yishun","sengkang","orchard"] #location
E004 = ["central","north","south","east","west"] #area
E005 = ["spicy","crispy","fresh"] #taste
E006 = ["today","tomorrow","tonight","tomorrow night","this afternoon","tomorrow afternoon"]
E009 = ["boon tong kee","poulet","hummus & grill","mama soi"]

P001 = ["i am looking for","any recommendation for","actually i am looking for"]
P002 = ["good","great","delicious","tasty"]
P003 = ["at","in"]
P004 = ["area"]
P005 = ["around","ard","near"]
P006 = ["cuisine","restaurant","food"]
P007 = ["yes"]
P008 = ["no", "it's okay","thanks it's okay","thanks, it's okay"]
P009 = ["something","somewhere"]
P010 = ["near to","nearer to"]
P011 = ["food","it","the food"]
P012 = ["service","the service"]
P013 = ["ambience","environment","the ambience","the environment"]
P014 = ["price","the price"]
P015 = ["not tasty","lousy","bad","not good","not great","poor"]
P016 = ["hi hi","hey","what's up","hey there"]
P017 = ["is","was","are","were"]
P018 = ["the"]
P019 = ["so so","alright","still alright","not bad","not too bad","not fantastic","average","reasonable","okay"]
P020 = ["expensive"]
P021 = ["cheap","low","a steal"]
P022 = ["very","super","extremely","unbelievably","ridiculously"]
P023 = ["it is","it's","it was"]
P024 = ["~ person","~ people","~ pax"]
P025 = ["how about"]
P026 = ["for"]
P027 = ["and","but"]
P028 = ["~pm", "~:~~pm", "~ pm", "~:~~ pm", "~ o'clock"]
P029 = ["hi","hello","hi there","good afternoon","good morning"]
P030 = ["feedback"]
P031 = ["recommendation"]
P032 = ["nothing interest me","just nothing interest me","any other options"]


entities = [E001,E002,E003,E004,E005,E006,E009]
entity_types = ['E001','E002','E003','E004','E005','E006','E009']
phases = [P001,P002,P003,P004,P005,P006,P007,P008,P009,P010,P011,P012,P013,P014,P015,P016,P017,P018,P019,P020,P021,P022,P023,P024,P025,P026,P027,P028,P029,P030,P031,P032]
phase_types = ['P001','P002','P003','P004','P005','P006','P007',
'P008','P009','P010','P011','P012','P013','P014','P015','P016',
'P017','P018','P019','P020','P021','P022','P023','P024','P025',
'P026','P027','P028','P029','P030','P031','P032']


from openpyxl import load_workbook


def data_extraction(filepath="app/neo4j_graph/lower_NodeData.xlsx"):
    wb=load_workbook(filepath)
    sheets = wb.sheetnames
    print(sheets)

    data = wb[sheets[1]]
    properties = []
    for j in range(len(data[1])):
        properties.append(data[1][j].value)
    print(properties)

    rows = data.max_row
    print(rows)
    records = []

    ## E001
    for r in range(rows - 1):
        records.append((data.cell(row=r + 2, column=1).value).strip())
    records = list(set(records))
    for e in records:
        Entity.add_entity('E001',e)

    ## E002
    for r in range(rows - 1):
        if "," in data.cell(row=r + 2, column=2).value:
            for s in (data.cell(row=r + 2, column=2).value).split(','):
              records.append(s.strip())
        else:
            records.append((data.cell(row=r + 2, column=2).value).strip())
    records = list(set(records))
    for e in records:
        Entity.add_entity('E002',e)


    ## E003
    data = wb[sheets[3]]
    properties = []
    for j in range(len(data[1])):
        properties.append(data[1][j].value)
    print(properties)

    rows = data.max_row
    print(rows)
    records = []

    for r in range(rows - 1):
        if "," in data.cell(row=r + 2, column=1).value:
            for s in (data.cell(row=r + 2, column=1).value).split(','):
              records.append(s.strip())
        else:
            records.append((data.cell(row=r + 2, column=1).value).strip())
    records = list(set(records))
    for e in records:
        Entity.add_entity('E003',e)

    ## E004
    data = wb[sheets[2]]
    properties = []
    for j in range(len(data[1])):
        properties.append(data[1][j].value)
    print(properties)

    rows = data.max_row
    print(rows)
    records = []

    for r in range(rows - 1):
        if "," in data.cell(row=r + 2, column=1).value:
            for s in (data.cell(row=r + 2, column=1).value).split(','):
              records.append(s.strip())
        else:
            records.append((data.cell(row=r + 2, column=1).value).strip())
    records = list(set(records))
    for e in records:
        Entity.add_entity('E004',e)

    ## E009
    data = wb[sheets[0]]
    properties = []
    for j in range(len(data[1])):
        properties.append(data[1][j].value)
    print(properties)

    rows = data.max_row
    print(rows)
    records = []

    for r in range(rows - 1):
        if "," in data.cell(row=r + 2, column=2).value:
            for s in (data.cell(row=r + 2, column=2).value).split(','):
              records.append(s.strip())
        else:
            records.append((data.cell(row=r + 2, column=2).value).strip())
    records = list(set(records))
    for e in records:
        Entity.add_entity('E009',e)


    #E005
    wb=load_workbook("app/neo4j_graph/lower_RelData.xlsx")
    sheets = wb.sheetnames
    data = wb[sheets[3]]
    properties = []
    for j in range(len(data[1])):
        properties.append(data[1][j].value)
    print(properties)

    rows = data.max_row
    print(rows)
    records = []

    for r in range(rows - 1):
        if "," in data.cell(row=r + 2, column=4).value:
            for s in (data.cell(row=r + 2, column=4).value).split(','):
              records.append(s.strip())
        else:
            records.append((data.cell(row=r + 2, column=4).value).strip())
    records = list(set(records))
    for e in records:
        Entity.add_entity('E005',e)



    # for i in range(len(sheets)):
    #     i == 1:
    #     data = wb[sheets[i]]
    #     properties = []
    #     for j in range(len(data[1])):
    #         properties.append(data[1][j].value)
    #     print(properties)

    #     rows = data.max_row
    #     print(rows)
    #     records = []
    #     for r in range(rows - 1):
    #         record = {}
    #         for c in range(len(properties)):
    #             record[properties[c]] = data.cell(row=r + 2, column=c + 1).value
    #         records.append(record)

    #     if i == 0:
    #         res_records = records
    #     elif i == 1:
    #         food_records = records
    #     elif i == 2:
    #         mrt_records = records
    #     elif i == 3:
    #         area_records = records
    #     else:
    #         user_records = records
    # return res_records,food_records,mrt_records,area_records,user_records

# data_extraction()
app = create_app()
with app.app_context():
    with db.auto_commit():
        for index,_entity in enumerate(entities):
            label = entity_types[index]
            for e in _entity:
                print(e)
                Entity.add_entity(label,e)
        for index,_phase in enumerate(phases):
            label = phase_types[index]
            for p in _phase:
                print(p)
                Phase.add_phase(label,p)
        data_extraction()


        
        # db.session.flush()

        # user = User()
        # user.username = 'pedro'
        # user.password = '123456'
        # user.email = '123456780000@qq.com'
        # db.session.add(user)

        # auth = Auth()
        # auth.auth = '删除图书'
        # auth.module = '图书'
        # auth.group_id = group.id
        # db.session.add(auth)