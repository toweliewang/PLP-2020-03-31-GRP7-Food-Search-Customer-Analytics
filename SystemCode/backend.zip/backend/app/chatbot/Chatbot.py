#!/usr/bin/env python
# -*- encoding: utf-8 -*-
'''
@File    :   MuseumDeail.py
@Time    :   2019/08/08 12:46:30
@Author  :   XU JIACHEN 
@Version :   1.0
@Contact :   e0402032@u.nus.edu liyingxujiachen@gmail.com
@Desc    :   get all data about museum basic information
'''
# here put the import lib
from flask_assistant import ask, tell, event, build_item
import os

from app.libs.redis_ctl import RedisCtl
import json
import random
import re
import joblib
import pandas as pd

from app.models.entity import Entity
from app.models.phase import Phase
from app.models.feedback import Feedback
from app.models.qa import QA

import time
import threading

from app.neo4j_graph.function_api import query_res,query_user,user_rel,filter_res

from deeppavlov import build_model, configs

from app.libs.models import Singleton

class Chatbot(object):

    r_restaurantName = ""
    r_address = ""
    r_cuisine = ""
    searchByMRT = False
  
    def __init__(self):
        self.E001 = Entity.get_for_entites_bytype('E001') #taste
        self.E002 = Entity.get_for_entites_bytype('E002') #taste
        self.E003 = Entity.get_for_entites_bytype('E003') #taste
        self.E004 = Entity.get_for_entites_bytype('E004') #taste
        self.E005 = Entity.get_for_entites_bytype('E005') #taste
        self.E006 = Entity.get_for_entites_bytype('E006') #taste
        self.E009 = Entity.get_for_entites_bytype('E009') #taste

        #self.E001 = ["chicken","chicken rice","cake","salad","lobster tail","crab"]
        #self.E002 = ["asian","japanese","chinese"]
        #self.E003 = ["downtown core","ang mo kio","yishun","toa payoh","serangoon","orchard","changi"]
        #self.E004 = ["orchard mrt station"]
        #self.E005 = ['fresh']
        #self.E006 = ["today","tomorrow","tonight","tomorrow night","this afternoon","tomorrow afternoon"]
        #self.E009 = ["boon tong kee","poulet","hummus & grill","mama soi"]

        self.P001 = Phase.get_for_phase_bytype('P001')
        self.P002 = Phase.get_for_phase_bytype('P002')
        self.P003 = Phase.get_for_phase_bytype('P003')
        self.P004 = Phase.get_for_phase_bytype('P004')
        self.P005 = Phase.get_for_phase_bytype('P005')
        self.P006 = Phase.get_for_phase_bytype('P006')
        self.P007 = Phase.get_for_phase_bytype('P007')
        self.P008 = Phase.get_for_phase_bytype('P008')
        self.P009 = Phase.get_for_phase_bytype('P009')
        self.P010 = Phase.get_for_phase_bytype('P010')
        self.P011 = Phase.get_for_phase_bytype('P011')
        self.P012 = Phase.get_for_phase_bytype('P012')
        self.P013 = Phase.get_for_phase_bytype('P013')
        self.P014 = Phase.get_for_phase_bytype('P014')
        self.P015 = Phase.get_for_phase_bytype('P015')
        self.P016 = Phase.get_for_phase_bytype('P016')
        self.P017 = Phase.get_for_phase_bytype('P017')
        self.P018 = Phase.get_for_phase_bytype('P018')
        self.P019 = Phase.get_for_phase_bytype('P019')
        self.P020 = Phase.get_for_phase_bytype('P020')
        self.P021 = Phase.get_for_phase_bytype('P021')
        self.P022 = Phase.get_for_phase_bytype('P022')
        self.P023 = Phase.get_for_phase_bytype('P023')
        self.P024 = Phase.get_for_phase_bytype('P024')
        self.P025 = Phase.get_for_phase_bytype('P025')
        self.P026 = Phase.get_for_phase_bytype('P026')
        self.P027 = Phase.get_for_phase_bytype('P027')
        self.P028 = Phase.get_for_phase_bytype('P028')
        self.P029 = Phase.get_for_phase_bytype('P029')
        self.P030 = Phase.get_for_phase_bytype('P030')
        self.P031 = Phase.get_for_phase_bytype('P031')
        self.P032 = Phase.get_for_phase_bytype('P032')

        #self.P011 = ["food","it","the food"]
        #self.P012 = ["service","the service"]
        #self.P013 = ["ambience","environment","the ambience","the environment"]
        #self.P014 = ["price","the price","it"]
        #self.P015 = ["not tasty","lousy","bad","not good","not great","poor"]
        #self.P016 = ["hi hi","hey","what's up","hey there"]
        #self.P017 = ["is","was","are","were"]
        #self.P018 = ["the","the price","it"]
        #self.P019 = ["so so","alright","still alright","not bad","not too bad","not fantastic","average","reasonable","okay"]
        #self.P020 = ["expensive"]
        #self.P021 = ["cheap","low","a steal"]
        #self.P022 = ["very","super","extremely","unbelievably","ridiculously"]
        #self.P023 = ["it is","it's","it was"]
        #self.P024 = ["~ person","~ people","~ pax"]
        #self.P025 = ["how about"]
        #self.P026 = ["for"]
        #self.P027 = ["and","but"]
        #self.P028 = ["~pm", "~:~~pm", "~ pm", "~:~~ pm", "~ o'clock"]
        #self.P029 = ["hi","hello","hi there","good afternoon","good morning"]
        #self.P030 = ["feedback"]
        #self.P031 = ["recommendation"]
        #self.P032 = ["nothing interest me","just nothing interest me","any other options"]

        #1 to 3 - Search for dish
        self.I001_001 = [self.P001,self.E001]
        self.I001_002 = [self.P001,self.P002,self.E001]
        self.I001_003 = [self.P001,self.E005,self.E001]

        self.I001 = [self.I001_001,self.I001_002,self.I001_003]

        #4 to 9 - Search for dish at location
        self.I002_001 = [self.P001,self.E001,self.P003,self.E003]
        self.I002_002 = [self.P001,self.E001,self.P005,self.E004]
        self.I002_003 = [self.P001,self.P002,self.E001,self.P003,self.E003]
        self.I002_004 = [self.P001,self.P002,self.E001,self.P005,self.E004]
        self.I002_005 = [self.P001,self.E005,self.E001,self.P003,self.E003]
        self.I002_006 = [self.P001,self.E005,self.E001,self.P005,self.E004]

        self.I002 = [self.I002_001,self.I002_002,self.I002_003,self.I002_004,
                      self.I002_005,self.I002_006]

        #10 to 11 - Search for cuisine
        self.I003_001 = [self.P001,self.E002,self.P006]
        self.I003_002 = [self.P001,self.P002,self.E002,self.P006]

        self.I003 = [self.I003_001,self.I003_002]

        #12 to 15 - Search for cuisine at location
        self.I004_001 = [self.P001,self.E002,self.P006,self.P003,self.E003]
        self.I004_002 = [self.P001,self.E002,self.P006,self.P005,self.E004]
        self.I004_003 = [self.P001,self.P002,self.E002,self.P006,self.P003,self.E003]
        self.I004_004 = [self.P001,self.P002,self.E002,self.P006,self.P005,self.E004]

        self.I004 = [self.I004_001,self.I004_002,self.I004_003,self.I004_004]

        #16 to 17 - Give dish
        self.I005_001 = [self.E001]
        self.I005_002 = [self.E005,self.E001]

        #18 - yes
        self.I006_001 = [self.P007]

        #19 - No
        self.I007_001 = [self.P008]

        #20 to 21 - Give location
        self.I008_001 = [self.E003]
        self.I008_002 = [self.E004]

        #22 to #25 - Give additional location input after recommendation
        self.I009_001 = [self.P001,self.P009,self.P010,self.E003]
        self.I009_002 = [self.P001,self.P009,self.P010,self.E004]
        self.I009_003 = [self.P001,self.P009,self.P010,self.E003,self.P004]
        self.I009_004 = [self.P001,self.P009,self.P010,self.E004,self.P004]

        self.I009 = [self.I009_001,self.I009_002,self.I009_003,self.I009_004]

        #26 - Give additional cuisine input after recommendation
        self.I010_001 = [self.P001,self.E002,self.P006]

        #61 - Feedback that there is nothing interesting
        self.I024_001 = [self.P032]

        #27 - Give Restaurant name
        self.I012_001 = [self.E009]

        #28 - Give day, time and pax for reservation
        self.I013_001 = [self.E006,self.P028,self.P026,self.P024]

        #60 - Give time, day and pax for reservation
        self.I013_002 = [self.P028,self.E006,self.P026,self.P024]

        self.I013 = [self.I013_001,self.I013_002]

        #29 to 32 - Give feedback on specific dish
        self.I014_001 = [self.P018,self.E001,self.P017,self.P002]
        self.I014_002 = [self.P018,self.E001,self.P017,self.P015]
        self.I014_003 = [self.P018,self.E001,self.P017,self.P019]
        self.I014_004 = [self.P018,self.E001,self.P017,self.E005]

        #33 to 36 - Give feedback on Food in General
        self.I015_001 = [self.P011,self.P017,self.P002]
        self.I015_002 = [self.P011,self.P017,self.P015]
        self.I015_003 = [self.P011,self.P017,self.P019]
        self.I015_004 = [self.P011,self.P017,self.E005]

        #37 - Give dish with 'the'
        self.I016_001 = [self.P018,self.E001]

        #38 to 40 - Give feedback on Service
        self.I017_001 = [self.P018,self.P012,self.P017,self.P002]
        self.I017_002 = [self.P018,self.P012,self.P017,self.P015]
        self.I017_003 = [self.P018,self.P012,self.P017,self.P019]

        #41 to 43 - Give feedback on Price
        self.I018_001 = [self.P014,self.P017,self.P019]
        self.I018_002 = [self.P014,self.P017,self.P020]
        self.I018_003 = [self.P014,self.P017,self.P021]

        #44 to 46 - Give feedback on Ambience
        self.I019_001 = [self.P018,self.P013,self.P017,self.P002]
        self.I019_002 = [self.P018,self.P013,self.P017,self.P015]
        self.I019_003 = [self.P018,self.P014,self.P017,self.P019]

        #47 to 55 - Give feedback on Service and Ambience
        self.I020_001 = [self.P012,self.P017,self.P002,self.P027,self.P013,self.P017,self.P002]
        self.I020_002 = [self.P012,self.P017,self.P002,self.P027,self.P013,self.P017,self.P015]
        self.I020_003 = [self.P012,self.P017,self.P002,self.P027,self.P013,self.P017,self.P019]
        self.I020_004 = [self.P012,self.P017,self.P015,self.P027,self.P013,self.P017,self.P002]
        self.I020_005 = [self.P012,self.P017,self.P015,self.P027,self.P013,self.P017,self.P015]
        self.I020_006 = [self.P012,self.P017,self.P015,self.P027,self.P013,self.P017,self.P019]
        self.I020_007 = [self.P012,self.P017,self.P019,self.P027,self.P013,self.P017,self.P002]
        self.I020_008 = [self.P012,self.P017,self.P019,self.P027,self.P013,self.P017,self.P015]
        self.I020_009 = [self.P012,self.P017,self.P019,self.P027,self.P013,self.P017,self.P019]

        #56 - formal greeting
        self.I021_001 = [self.P016]

        #57 - informal greeting
        self.I021_002 = [self.P029]

        #58 - feedback keyword
        self.I022_001 = [self.P030]

        #59 - recommendation keyword
        self.I023_001 = [self.P031]

        self.phases = [self.I001_001,self.I001_002,self.I001_003,self.I002_001,self.I002_002,self.I002_003,self.I002_004,self.I002_005,self.I002_006,self.I003_001,self.I003_002,self.I004_001,self.I004_002,
          self.I004_003,self.I004_004,self.I005_001,self.I005_002,self.I006_001,self.I007_001,self.I008_001,self.I008_002,self.I009_001,self.I009_002,self.I009_003,self.I009_004,self.I010_001,
          self.I012_001,self.I013_001,self.I014_001,self.I014_002,self.I014_003,self.I014_004,self.I015_001,self.I015_002,self.I015_003,self.I015_004,self.I016_001,self.I017_001,self.I017_002,
          self.I017_003,self.I018_001,self.I018_002,self.I018_003,self.I019_001,self.I019_002,self.I019_003,self.I020_001,self.I020_002,self.I020_003,self.I020_004,self.I020_005,self.I020_006,
          self.I020_007,self.I020_008,self.I020_009,self.I021_001,self.I021_002,self.I022_001,self.I023_001,self.I013_002,self.I024_001]

        self.isEntity = [[0,1],[0,0,1],[0,5,1],[0,1,0,3],[0,1,0,4],[0,0,1,0,3],[0,0,1,0,4],[0,5,1,0,3],[0,5,1,0,4],[0,2,0],[0,0,2,0],
            [0,2,0,0,3],[0,2,0,0,4],[0,0,2,0,0,3],[0,0,2,0,0,4],[1],[5,1],[0],[0],[3],[4],[0,0,0,3],[0,0,0,4],[0,0,0,3,0],
            [0,0,0,4,0],[0,2,0],[9],[6,7,0,8],[0,1,0,0],[0,1,0,0],[0,1,0,0],[0,1,0,5],[0,0,0],[0,0,0],[0,0,0],[0,0,5],
            [0,1],[0,0,0,0],[0,0,0,0],[0,0,0,0],[0,0,0],[0,0,0],[0,0,0],[0,0,0,0],[0,0,0,0],[0,0,0,0],[0,0,0,0,0,0,0,0,0],
            [0,0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0,0],
            [0,0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0,0],[0],[0],[0],[0],[7,6,0,8],[0]]

        #User specific variables

        self.state = 0 
        self.entity = ["","","","","","","","","",""]
        self.ml_entity = ["","","","","","","","","",""]
        self.prev_input =''
        self.restaurantList = []
        self.showList = False
        self.restaurantName = ""
        self.address = ""
        self.cuisine = ""

        models = Singleton.instance()
        
        self.multiModel = models.chatbotmodel

        # model = build_model(configs.squad.squad, download=True)
        self.model = models.qamodel

        data = pd.read_csv("SingaporeCuisine.csv")
        text = data['Para']
 
        self.combinedText = ""
        for i in range(len(text)):
           self.combinedText +=text[i]

    def trim(self,inputText):
        index = 0
        while inputText[index] == ' ':
            inputText = inputText[index+1:]
        index = len(inputText) - 1
        while inputText[index] == ' ':
            inputText = inputText[:index]
            index -= 1    
        return inputText

    def updateFST(self,intentList,inputString):
        
        candidate = []
        index = 0
        for i in range(len(intentList)):
            length = len(intentList[i])
            for j in range(len(intentList[i])):
                for k in range(len(intentList[i][j])):
                    if intentList[i][j][k] in inputString:
                        length -= 1
                        break
            if length == 1:
                candidate.append(i)
        #print(candidate) 
        
        if len(candidate) == 0:
            return
        
        longest = 0
        for i in range(len(candidate)):
            if longest < len(intentList[(candidate[i])]):
                longest = len(intentList[(candidate[i])])
                index = i

        index = candidate[index]
        subIndex = 99
        #print(intentList[index])

        for i in range(len(intentList[index])):
            matched = False
            for j in range(len(intentList[index][i])):
                if intentList[index][i][j] in inputString:
                    matched = True
                    inputString = inputString.replace(intentList[index][i][j] + ' ','')
                    inputString = inputString.replace(' ' + intentList[index][i][j],'')
                    break
            if matched == False:
                subIndex = i
                #print(i)

        #print(intentList[index][subIndex])
        #print(inputString)

        inputString = self.trim(inputString)

        if self.P001 == intentList[index][subIndex]:
            Phase.add_phase("P001",inputString)
            self.P001.append(inputString)
        elif self.P002 == intentList[index][subIndex]:
            Phase.add_phase("P002",inputString)
            self.P002.append(inputString)
        elif self.P003 == intentList[index][subIndex]:
            Phase.add_phase("P003",inputString)
            self.P003.append(inputString)
        elif self.P004 == intentList[index][subIndex]:
            Phase.add_phase("P004",inputString)
            self.P004.append(inputString)
        elif self.P005 == intentList[index][subIndex]:
            Phase.add_phase("P005",inputString)
            self.P005.append(inputString)
        elif self.P006 == intentList[index][subIndex]:
            Phase.add_phase("P006",inputString)
            self.P006.append(inputString)
        elif self.P007 == intentList[index][subIndex]:
            Phase.add_phase("P007",inputString)
            self.P007.append(inputString)
        elif self.P008 == intentList[index][subIndex]:
            Phase.add_phase("P008",inputString)
            self.P008.append(inputString)
        elif self.P009 == intentList[index][subIndex]:
            Phase.add_phase("P009",inputString)
            self.P009.append(inputString)
        elif self.P010 == intentList[index][subIndex]:
            Phase.add_phase("P010",inputString)
            self.P010.append(inputString)
        elif self.P011 == intentList[index][subIndex]:
            Phase.add_phase("P011",inputString)
            self.P011.append(inputString)
        elif self.P012 == intentList[index][subIndex]:
            Phase.add_phase("P012",inputString)
            self.P012.append(inputString)
        elif self.P013 == intentList[index][subIndex]:
            Phase.add_phase("P013",inputString)
            self.P013.append(inputString)
        elif self.P014 == intentList[index][subIndex]:
            Phase.add_phase("P014",inputString)
            self.P014.append(inputString)
        elif self.P015 == intentList[index][subIndex]:
            Phase.add_phase("P015",inputString)
            self.P015.append(inputString)
        elif self.P016 == intentList[index][subIndex]:
            Phase.add_phase("P016",inputString)
            self.P016.append(inputString)
        elif self.P017 == intentList[index][subIndex]:
            Phase.add_phase("P017",inputString)
            self.P017.append(inputString)
        elif self.P018 == intentList[index][subIndex]:
            Phase.add_phase("P018",inputString)
            self.P018.append(inputString)
        elif self.P019 == intentList[index][subIndex]:
            Phase.add_phase("P019",inputString)
            self.P019.append(inputString)
        elif self.P020 == intentList[index][subIndex]:
            Phase.add_phase("P020",inputString)
            self.P020.append(inputString)
        elif self.P021 == intentList[index][subIndex]:
            Phase.add_phase("P021",inputString)
            self.P021.append(inputString)
        elif self.P022 == intentList[index][subIndex]:
            Phase.add_phase("P022",inputString)
            self.P022.append(inputString)
        elif self.P023 == intentList[index][subIndex]:
            Phase.add_phase("P023",inputString)
            self.P023.append(inputString)
        elif self.P024 == intentList[index][subIndex]:
            Phase.add_phase("P024",inputString)
            self.P024.append(inputString)
        elif self.P025 == intentList[index][subIndex]:
            Phase.add_phase("P025",inputString)
            self.P025.append(inputString)
        elif self.P026 == intentList[index][subIndex]:
            Phase.add_phase("P026",inputString)
            self.P026.append(inputString)
        elif self.P027 == intentList[index][subIndex]:
            Phase.add_phase("P027",inputString)
            self.P027.append(inputString)
        elif self.P028 == intentList[index][subIndex]:
            Phase.add_phase("P028",inputString)
            self.P028.append(inputString)
        elif self.P029 == intentList[index][subIndex]:
            Phase.add_phase("P029",inputString)
            self.P029.append(inputString)
        elif self.P030 == intentList[index][subIndex]:
            Phase.add_phase("P030",inputString)
            self.P030.append(inputString)
        elif self.P031 == intentList[index][subIndex]:
            Phase.add_phase("P031",inputString)
            self.P031.append(inputString)
        elif self.P032 == intentList[index][subIndex]:
            Phase.add_phase("P032",inputString)
            self.P032.append(inputString)

    def detectIntent(self,userInput):

        if re.match("^where",userInput) or re.match("^what",userInput) or re.match("^why",userInput):
            return 100

        for i in range(len(self.phases)):
        
            stringToTest = userInput
            matchFound = 0
            t_entity = ["","","","","","","","","",""]
            
            for j in range(len(self.phases[i])):
                for k in range(len(self.phases[i][j])):
                    lengthToMatch = len(self.phases[i][j][k])
                    expression = re.sub("~", "[0-9]", self.phases[i][j][k])
                    if re.match(expression,stringToTest[0:lengthToMatch]):
                        matchFound += 1
                        if self.isEntity[i][j] != 0:
                            t_entity[self.isEntity[i][j]-1] = stringToTest[0:lengthToMatch] #extract entity
                        stringToTest = stringToTest[lengthToMatch+1:]
                        break
                        
            if len(stringToTest) == 0 and matchFound == len(self.phases[i]):
                for l in range(len(t_entity)):
                    if t_entity[l] != "":
                        self.entity[l] = t_entity[l]
                return i + 1   
                break
        return 0

    def detectIntentML(self,userInput):

        data = pd.read_csv("bagOfWords.csv")
        bagOfWords = data['words'].values.tolist()
        
        userInputToken = []
        start = 0

        for i in range(len(userInput)):
            if userInput[i] == " ":
                userInputToken.append(userInput[start:i])
                start = i + 1
        userInputToken.append(userInput[start:])

        userInputBOW = [0] * 53
        for i in range (len(bagOfWords)):
            for j in range (len(userInputToken)):                
                    
                if bagOfWords[i]==userInputToken[j]:
                    userInputBOW[i] = 1

        for i in range (len(self.E001)):
            if self.E001[i] in userInput:
                userInputBOW[3]=1
                self.ml_entity[0]=self.E001[i]
                
        for i in range (len(self.E002)):
            if self.E002[i] in userInput:
                userInputBOW[11]=1
                self.ml_entity[1]=self.E002[i]
                
        for i in range (len(self.E003)):
            if self.E003[i] in userInput:
                userInputBOW[9]=1
                self.ml_entity[2]=self.E003[i]

        for i in range (len(self.E004)):
            if self.E004[i] in userInput:
                userInputBOW[23]=1
                self.ml_entity[3]=self.E004[i]
                
        for i in range (len(self.E005)):
            if self.E005[i] in userInput:
                userInputBOW[7]=1
                self.ml_entity[4]=self.E005[i]
                
        for i in range (len(self.E006)):
            if self.E006[i] in userInput:
                userInputBOW[27]=1
                self.ml_entity[5]=self.E006[i]
                
        if re.findall("[0-9]?:?[0-9]?[0-9]pm",userInput):
            userInputBOW[26]=1
            self.ml_entity[6]=re.findall("[0-9]?:?[0-9]?[0-9]pm",userInput)[0]
                
        if re.findall("[0-9] pax",userInput):
            userInputBOW[28]=1
            self.ml_entity[7]=re.findall("[0-9] pax",userInput)[0]
            
        y_pred = self.multiModel.predict([userInputBOW])  
    
        return(int(y_pred))

    def searchRestaurant(self,user_id):

        #id=123456000
        print(user_id)
        global searchByMRT
        searchByMRT = False

        if self.entity[0] != "" and self.entity[3] != "" and self.entity[4] != "":
            #search by taste, food and mrt station
            query={'taste':self.entity[4],'food':self.entity[0]}
            result1=query_res(**query)
            query={'mrt':self.entity[3]}
            result2 = query_res(**query)
            self.restaurantList = filter_res(result1,result2)
            ref={'food':self.entity[0]}
            user_rel(user_id,**ref)
            ref={'mrt':self.entity[3]}
            user_rel(user_id,**ref)
            searchByMRT = True
        elif self.entity[0] != "" and self.entity[2] != "" and self.entity[4] != "":
            #search by taste, food and area
            query={'taste':self.entity[4],'food':self.entity[0]}
            result1=query_res(**query)
            query={'area':self.entity[2]}
            result2 = query_res(**query)
            self.restaurantList = filter_res(result1,result2)
            ref={'food':self.entity[0]}
            user_rel(user_id,**ref)
            ref={'area':self.entity[2]}
            user_rel(user_id,**ref)
        elif self.entity[0] != "" and self.entity[4] != "":
            #search by taste and food
            query={'taste':self.entity[4],'food':self.entity[0]}
            self.restaurantList=query_res(**query)
            ref={'food':self.entity[0]}
            user_rel(user_id,**ref)
        elif self.entity[0] != "" and self.entity[3] != "":
             #search by food and mrt station
            query={'food':self.entity[0]}
            result1 = query_res(**query)
            query={'mrt':self.entity[3]}
            result2 = query_res(**query)
            self.restaurantList = filter_res(result1,result2)
            ref={'mrt':self.entity[3]}
            user_rel(user_id,**ref)
            searchByMRT = True
        elif self.entity[0] != "" and self.entity[2] != "":
            #search by food and area
            query={'food':self.entity[0]}
            result1 = query_res(**query)
            query={'area':self.entity[2]}
            result2 = query_res(**query)
            self.restaurantList = filter_res(result1,result2)
            ref={'area':self.entity[2]}
            user_rel(user_id,**ref)
            ref={'food':self.entity[0]}
            user_rel(user_id,**ref)
        elif self.entity[0] != "":
            #search by food
            query={'food':self.entity[0]}
            self.restaurantList = query_res(**query)
            ref={'food':self.entity[0]}
            user_rel(user_id,**ref)
        elif self.entity[1] != "" and self.entity[3] != "":
            #search by cuisine and mrt station
            query={'cuisine':self.entity[1]}
            result1 = query_res(**query)
            query={'mrt':self.entity[3]}
            result2 = query_res(**query)
            self.restaurantList = filter_res(result1,result2)  
            ref={'mrt':self.entity[3]}
            user_rel(user_id,**ref)
            searchByMRT = True
        elif self.entity[1] != "" and self.entity[2] != "":
            #search by cuisine and location
            query={'cuisine':self.entity[1]}
            result1 = query_res(**query)
            query={'area':self.entity[2]}
            result2 = query_res(**query)
            self.restaurantList = filter_res(result1,result2)  
            ref={'area':self.entity[2]}
            user_rel(user_id,**ref)    
        elif self.entity[1] != "":
            #search by cuisine
            query={'cuisine':self.entity[1]}
            self.restaurantList = query_res(**query)   

    def intentDetector(self,inputText,user_id):
        
        formal = 1
        response = ""
        global r_restaurantName
        global r_address
        global r_cuisine
        
        inputText = inputText.lower()
        inputText = inputText.replace('?','')
        inputText = inputText.replace('.','')
        detectedIntent = self.detectIntent(inputText)

        #Machine Learning Model Detection Attempt
        if detectedIntent == 0:
            detectedIntent = self.detectIntentML(inputText) + 1000
        
        print("State: " + str(self.state))
        print("Intent: " + str(detectedIntent))

        #Response Matching
        if detectedIntent in (1,2,3) and self.state == 0:
            response = "Any preferred location?"
            self.state = 1
        elif detectedIntent in (10,11) and self.state == 0:
            responseText=["Any specific dish?","Any specific dish you are thinking about?"]
            response = responseText[formal]
            self.state = 2
        elif detectedIntent in (16,17,19) and self.state == 2:
            response = "Any preferred location?"
            self.state = 3           
        elif detectedIntent in (12,13,14,15) and self.state == 0:
            responseText=["Any specific dish?","Any specific dish you are thinking about?"]
            response = responseText[formal]
            self.state = 4
        elif detectedIntent in (4,5,6,7,8,9,16,17,19,20,21) and self.state in (0,1,3,4):
            #search for dish
            self.searchRestaurant(user_id)
            if self.restaurantList is None:
                response = "Sorry, at the moment I did not find anything that matches your requirement. Please try again at a later date."
                self.state = 0
            else:
                self.showList = True
                responseText=["I have found these. Anything you like? Click on the one you like to make a reservation.","I have found these for you. Does any of them interest you? Click on the restaurant you are interested in to make a reservation."]
                response = responseText[formal]
                self.state = 6     
        #elif detectedIntent == 27 and self.state in (5,9,10):
        #    responseText=["I make a reservation for you?","Great choice, would you like me to make a reservation for you?"]
        #    response = responseText[formal]
        #    self.state = 6
        elif detectedIntent in (18,27) and self.state in (6,9,10,20):
            if detectedIntent == 18:
                self.entity[8] = r_restaurantName
            responseText=["which day, what time and for how many pax?","May I know if you are looking today or tomorrow, what time and for how many pax?"]
            response = responseText[formal]
            self.state = 7
        elif detectedIntent in (28,60) and self.state == 7:
            response = "Your reservation for " + self.entity[7] + " at " + self.entity[8] + " at " + self.entity[6] + " " + self.entity[5] +" is confirmed. Have a great day!"
            self.entity[9] = self.entity[8]
            Feedback.add_feedback(user_id,self.entity[8]) 
            self.state = 0
        elif detectedIntent == 19 and self.state == 6:
            response = "why not?"
            self.state = 8
        elif detectedIntent == 61 and self.state == 8:
            if len(self.restaurantList) > 0:
                response = "I see, how about these?"
                self.showList = True
                self.state = 9
            else:
                response = "Sorry, at the moment I did not find other restaurants that meets your requirement. Perhaps you would like to try again at a later date."
                self.state = 0
        elif detectedIntent in (1,3,22,23,24,25,26) and self.state in (6,8):
            #search again with new input
            self.searchRestaurant(user_id)
            if self.restaurantList is None:
                response = "Sorry, at the moment I did not find anything that matches your new requirement. Please try again on a later date."
                self.state = 0
            else:
                self.showList = True
                response = "I see, how about these?"
                self.state = 9
        elif detectedIntent == 19 and self.state == 9:
            #return next set of result
            if len(self.restaurantList) > 0:
                response = "Or these?"
                self.showList = True # check if restaurant list is empty
                self.state = 10
            else:
                response = "Sorry, at the moment I did not find other restaurants that meets your requirement. Perhaps you would like to try again at a later date."
                self.state = 0
        elif detectedIntent == 19 and self.state == 10:
            response = "Alright then, hope to be able to help you the next time."
            self.state = 0
        elif detectedIntent in (29,30,31,32):
            response = "Noted how about the price?"
            self.state = 12
        elif detectedIntent in (33,34,35,36):
            response = "Any dish in particular that you are referring to?"
            self.state = 13
        elif detectedIntent in (16,19,37) and self.state == 13:
            response = "Noted. How about the price?"
            self.state = 12
        elif detectedIntent in (41,42,43) and self.state == 12:
            response = "What about the service and ambience?"
            self.state = 14
        elif detectedIntent in (47,48,49,50,51,52,53,54,55) and self.state == 14:
            response = "Thank you for your feeback!"
            Feedback.get_feedback(user_id)
            self.state = 0
            
        elif detectedIntent in (41,42,43) and self.state == 11:
            response = "What about the food?"
            self.state = 15
        elif detectedIntent in (29,30,31,32) and self.state == 15:
            response = "Noted. How about the service and ambience?"
            self.state = 14
        elif detectedIntent in (33,34,35,36) and self.state == 15:
            response = "Any dish in particular that you are referring to?"
            self.state = 16    
        elif detectedIntent in (16,19,37) and self.state == 16:
            response = "Noted. How about the service and ambience?"
            self.state = 14
            
        elif detectedIntent in (38,39,40,44,45,46) and self.state == 11:
            response = "Noted. How about the food?"
            self.state = 17
            
        elif detectedIntent in (29,30,31,32) and self.state == 17:
            response = "Noted. What about the price?"
            self.state = 18
        elif detectedIntent in (33,34,35,36) and self.state == 17:
            response = "Any dish in particular that you are referring to?"
            self.state = 19   
        elif detectedIntent in (41,42,43) and self.state == 18:
            response = "Thank you for your feeback!"
            Feedback.get_feedback(user_id)
            self.state = 0
        elif detectedIntent in (16,19,37) and self.state == 19:
            response = "Noted. How about the price?"
            self.state = 18
        elif detectedIntent == 56:
            response = "Hey, what cuisine or dish are you craving for?"
            formal = 0
            self.state = 0
            self.entity[0] = ""
            self.entity[1] = ""
            self.entity[2] = ""
            self.entity[3] = ""
            self.entity[4] = ""
            self.entity[5] = ""
            self.entity[6] = ""
            self.entity[7] = ""
            self.entity[8] = ""
            self.ml_entity = ["","","","","","","","","",""]
            self.prev_input =''
            self.restaurantList = []
            self.showList = False
        elif detectedIntent == 57:
            response = "Hi, let me know what cuisine or dish you are thinking about and at what location."
            formal = 1
            self.state = 0 
            self.entity[0] = ""
            self.entity[1] = ""
            self.entity[2] = ""
            self.entity[3] = ""
            self.entity[4] = ""
            self.entity[5] = ""
            self.entity[6] = ""
            self.entity[7] = ""
            self.entity[8] = ""
            self.ml_entity = ["","","","","","","","","",""]
            self.prev_input =''
            self.restaurantList = []
            self.showList = False
        elif detectedIntent == 58:
            response = "How is the food at " + self.entity[9] + "?"
        elif detectedIntent == 59:
            response = "I found this restaurant call " + r_restaurantName + " which you might be interested to check out. It serves " + r_cuisine + " cuisine and it is located at " + r_address + ". Would you like me to make a reservation for you?" 
            self.state = 20
        elif detectedIntent == 19 and self.state == 20:
            response = "Alright, I will let you know when I find something interesting again." 
            self.state = 0
        elif detectedIntent == 100:
            #This is Q&A
            # response = model([self.combinedText], ['where can we eat at in Singapore?'])
            response = self.model([self.combinedText], [inputText])[0][0]
            # response = "This is Q&A"
        elif detectedIntent == 1000:
            if self.ml_entity[4] == 0:
                response = "Sorry I don't quite understand, are you looking for " + self.ml_entity[0] + "?"
            else:
                response = "Sorry I don't quite understand, are you looking for " + self.ml_entity[4] + " " + self.ml_entity[0] + "?"
            self.prev_input = inputText
            self.state = 101
        elif detectedIntent == 18 and self.state == 101:
            self.updateFST(self.I001,self.prev_input)
            response = "Any preferred location?"
            self.state = 1
            self.entity[0] = self.ml_entity[0]
            if self.ml_entity[4] != "":
                self.entity[4] = self.ml_entity[4]
                  
        elif detectedIntent == 19 and self.state in (101,102,103,104,105,107,108):
            response = "Looks like I didn't understand you correctly, please kindly try to rephase your sentence for me."
            self.state = 0
        elif detectedIntent == 1001:
            if self.ml_entity[4] == "":
                response = "Sorry I don't quite understand, are you looking for " + self.ml_entity[0] + " at " + self.ml_entity[2] + "?"
            else:
                response = "Sorry I don't quite understand, are you looking for " + self.ml_entity[4] + " " + self.ml_entity[0] + " at " + self.ml_entity[2] + "?"
            self.prev_input = inputText
            self.state = 102
        elif detectedIntent == 18 and self.state == 102:
            self.updateFST(self.I002,self.prev_input)

            self.entity[0] = self.ml_entity[0]
            self.entity[2] = self.ml_entity[2]
            if self.ml_entity[4] != "":
                self.entity[4] = self.ml_entity[4]

            self.searchRestaurant(user_id)
            if self.restaurantList is None:
                response = "Sorry, at the moment I did not find anything that matches your requirement. Please try again at a later date."
                self.state = 0
            else:
                self.showList = True
                responseText=["I have found these. Anything you like? Click on the one you like to make a reservation.","I have found these for you. Does any of them interest you? Click on the restaurant you are interested in to make a reservation."]
                response = responseText[formal]
                self.state = 6 

        elif detectedIntent == 1018:
            if self.ml_entity[4] == "":
                response = "Sorry I don't quite understand, are you looking for " + self.ml_entity[0] + " near " + self.ml_entity[3] + "?"
            else:
                response = "Sorry I don't quite understand, are you looking for " + self.ml_entity[4] + " " + self.ml_entity[0] + " near " + self.ml_entity[3] + "?"
            self.prev_input = inputText
            self.state = 107
        elif detectedIntent == 18 and self.state == 107:
            self.updateFST(self.I002,self.prev_input)

            self.entity[0] = self.ml_entity[0]
            self.entity[3] = self.ml_entity[3]
            if self.ml_entity[4] != "":
                self.entity[4] = self.ml_entity[4]

            self.searchRestaurant(user_id)
            if self.restaurantList is None:
                response = "Sorry, at the moment I did not find anything that matches your requirement. Please try again at a later date."
                self.state = 0
            else:
                self.showList = True
                responseText=["I have found these. Anything you like? Click on the one you like to make a reservation.","I have found these for you. Does any of them interest you? Click on the restaurant you are interested in to make a reservation."]
                response = responseText[formal]
                self.state = 6 
            
        elif detectedIntent == 1002:
            response = "Sorry I don't quite understand, are you looking for " + self.ml_entity[1] + " cuisine?"
            self.prev_input = inputText
            self.state = 103
        elif detectedIntent == 18 and self.state == 103:
            self.updateFST(self.I003,self.prev_input)
            self.entity[1] = self.ml_entity[1]
            response = "Any specific dish you are thinking about?"
            self.state = 2
        elif detectedIntent == 1003:
            response = "Sorry I don't quite understand, are you looking for " + self.ml_entity[1] + " cuisine at " + self.ml_entity[2] + "?"
            self.prev_input = inputText
            self.state = 104
        elif detectedIntent == 18 and self.state == 104:
            self.updateFST(self.I004,self.prev_input)
            self.entity[1] = self.ml_entity[1]
            self.entity[2] = self.ml_entity[2]
            response = "Any specific dish you are thinking about?"
            self.state = 4
        elif detectedIntent == 1019:
            response = "Sorry I don't quite understand, are you looking for " + self.ml_entity[1] + " cuisine at " + self.ml_entity[3] + "?"
            self.prev_input = inputText
            self.state = 108
        elif detectedIntent == 18 and self.state == 108:
            self.updateFST(self.I004,self.prev_input)
            self.entity[1] = self.ml_entity[1]
            self.entity[3] = self.ml_entity[3]
            response = "Any specific dish you are thinking about?"
            self.state = 4          
        elif detectedIntent == 1008:
            if self.entity[3] != "":
                if self.entity[0] != "":
                    response = "Sorry I don't quite understand, are you looking for " + self.entity[0] + " at " + self.ml_entity[3] + "?"
                elif self.entity[1] != "":
                    response = "Sorry I don't quite understand, are you looking for " + self.entity[1] + " cuisine at " + self.ml_entity[3] + "?"
                else:
                    response = "Sorry I don't quite understand, are you looking for a place to eat at " + self.ml_entity[3] + "?"
            else:
                if self.entity[0] != "":
                    response = "Sorry I don't quite understand, are you looking for " + self.entity[0] + " at " + self.ml_entity[2] + "?"
                elif self.entity[1] != "":
                    response = "Sorry I don't quite understand, are you looking for " + self.entity[1] + " cuisine at " + self.ml_entity[2] + "?"
                else:
                    response = "Sorry I don't quite understand, are you looking for a place to eat at " + self.ml_entity[2] + "?"
            self.prev_input = inputText
            self.state = 105
        elif detectedIntent == 18 and self.state == 105:
            self.updateFST(self.I009,self.prev_input)
            if self.entity[3] != "":
                self.entity[3] = self.ml_entity[3]
            else:
                self.entity[2] = self.ml_entity[2]
            self.searchRestaurant(user_id)
            if self.restaurantList is None:
                response = "Sorry, at the moment I did not find anything that matches your new requirement. Please try again on a later date."
                self.state = 0
            else:
                self.showList = True
                response = "I see, how about these?"
                self.state = 9     
        elif detectedIntent == 1010:
            response = "To confirm, the reservation is for " + self.ml_entity[7] + " at " + self.entity[8] + " at " + self.ml_entity[6] + " " + self.ml_entity[5] +"?"
            self.prev_input = inputText
            self.state = 106
        elif detectedIntent == 18 and self.state == 106:
            self.updateFST(self.I013,self.prev_input)
            self.entity[5] = self.ml_entity[5]
            self.entity[6] = self.ml_entity[6]
            self.entity[7] = self.ml_entity[7]
            response = "Your reservation for " + self.entity[7] + " at " + self.entity[8] + " at " + self.entity[6] + " " + self.entity[5] +" is confirmed"
            Feedback.add_feedback(user_id,self.entity[8]) 
            self.state = 0   
        elif detectedIntent == 19 and self.state == 106:
            response = "Looks like I didn't understand you correctly, please kindly try to rephase your sentence for me"
            self.state = 7
        else:
            response = "Sorry I don't understand that."
        
        return response

    def getChartbotResponse(self,query_text,session_id,user_id):
        """
        desc :
        param :
        return :
        """
        global searchByMRT

        # connect the redis
        _redis = RedisCtl()

        conversation = {}

        # load the data from the redis database if the session exist
        if _redis.checkData(session_id):
          conversation = json.loads(_redis.getData(session_id))
          self.state = conversation['state']
          self.prev_input = conversation['prev_input']
          self.showList = conversation['showList']
          self.restaurantList = conversation['restaurantList']
          self.entity = conversation['entity']
          self.ml_entity = conversation['ml_entity']
        
        text = self.intentDetector(query_text,user_id)
        response = ask(text)

        if self.showList:
            response = response.build_list("Recommended Eateries")
            print("Number of records found: " + str(len(self.restaurantList)))
            counter = len(self.restaurantList)
            if counter > 3:
                counter = 3
            for i in range (counter):
                if searchByMRT:
                    response.add_item(self.restaurantList[i]['name'] + " (" + self.restaurantList[i]['cuisine'] + ")", key=self.restaurantList[i]['name'], description=self.restaurantList[i]['address'] + " (" + str(round(self.restaurantList[i]['distance'],2)) + " Km from " + self.entity[3] + " )", img_url="image")
                else:
                    response.add_item(self.restaurantList[i]['name'] + " (" + self.restaurantList[i]['cuisine'] + ")", key=self.restaurantList[i]['name'], description=self.restaurantList[i]['address'], img_url="image")
            for i in range (counter):
                self.restaurantList.pop(0)
            self.showList = False
            

        #response.card(text=intro_description,
        #          title=intro_title,
        #          img_url=intro_image,
        #          link_title="Read More",
        #          link=link
        #          )
        #response.suggest("Museum Open time", "Museum Location", "Museum Tickets")

        #conversation[state]["response"] = text


        # save the data into the database
        # save the data with timeout default 30mins if use the saveData_Timeout
        # use the saveData without any timeout limitation
        # _redis.saveData_Timeout(session_id,json.dumps(),6000)

        conversation['user_id'] = user_id
        conversation['state'] = self.state
        conversation['prev_input'] = self.prev_input
        conversation['showList'] = self.showList
        conversation['restaurantList'] = self.restaurantList
        conversation['entity'] = self.entity
        conversation['ml_entity'] = self.ml_entity

        _redis.saveData(session_id,json.dumps(conversation))

        return response

    def check_has_recommendation(user_id):

        global r_restaurantName
        global r_address
        global r_cuisine

        #id=123456000
        result,counts,result_type=query_user(user_id)
        #response = str(result_type[0]) + result[0]['name'] + str(counts[0]['count'])

        foodList = []
        foodListCount = []
        foodTotalCount = 0
        foodIndex = 0
        areaList = []
        areaListCount = []
        areaTotalCount = 0
        areaIndex = 0
        finalResult = []

        for i in range (len(result)):
            if str(result_type[i]) == ':food':
                foodList.append(result[i])
                foodListCount.append(counts[i]['count'])
                foodTotalCount += counts[i]['count']
                print("found food or cuisine")
            elif str(result_type[i]) == ':area':
                areaList.append(result[i])
                areaListCount.append(counts[i]['count'])
                areaTotalCount += counts[i]['count']
            
        print(len(foodList))
        foodRandomNumber = random.randint(0,foodTotalCount)
        counter = 0
        for i in range (len(foodList)):
            counter += foodListCount[i]
            if counter >= foodRandomNumber:
                foodIndex = i
                break

    
        if len(areaList) > 0 and len(foodList) > 0:
            areListRandomNumber = random.randint(0,areaTotalCount)
            counter = 0
            for i in range (len(areaList)):
                counter += areaListCount[i]
                if counter >= areListRandomNumber:
                    areaIndex = i
                    break
                
            query={'area':areaList[areaIndex]['name']}
            result1 = query_res(**query)
            query={'food':foodList[foodIndex]['name']}
            result2 = query_res(**query)
            finalResult = filter_res(result1,result2)
            
            if finalResult is None:
                query={'food':foodList[foodIndex]['name']}
                finalResult = query_res(**query)

        elif len(foodList) > 0:
            query={'food':foodList[foodIndex]['name']}
            finalResult = query_res(**query)

        elif len(areaList) > 0:
            areListRandomNumber = random.randint(0,areaTotalCount)
            counter = 0
            for i in range (len(areaList)):
                counter += areaListCount[i]
                if counter >= areListRandomNumber:
                    areaIndex = i
                    break
            query={'area':areaList[areaIndex]['name']}
            finalResult = query_res(**query)


        print(len(finalResult))
        if finalResult is not None:
            if len(finalResult) == 0:
                return False
            if len(finalResult) == 1:
                randomIndex = 0
            else:
                randomIndex = random.randint(0,len(finalResult)-1)
            r_restaurantName = finalResult[randomIndex]['name']
            r_address = finalResult[randomIndex]['address']
            r_cuisine = finalResult[randomIndex]['cuisine']
            return True
        else:
            return False