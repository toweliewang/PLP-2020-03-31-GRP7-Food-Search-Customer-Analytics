# -*- coding:utf-8 -*-


import sys, getopt,json,os,re
from redis_ctl import RedisQueue
from datetime import datetime
import time,ast


class RedisQueue_task():
    '''
    # redisQueue 队列任务类 用于不同队列组别的各类方法封装和生成
    '''
    def __init__(self,scan_group):
        self.task_queue = {"high":{"queue_name":"task_"+scan_group+"_hq",
                                    "queue_obj":RedisQueue('task_'+scan_group+'_hq')},
                            "normal":{"queue_name":"task_"+scan_group+"_nq",
                                    "queue_obj":RedisQueue('task_'+scan_group+'_nq')}}

    def scan_Queue(self,type):
        result = {}
        result["task_queue_name"] = self.task_queue[type]["queue_name"]
        result["task_queue"] = self.task_queue[type]["queue_obj"].scan_all()
        result["task_queue_size"] = self.task_queue[type]["queue_obj"].qsize()
        return result

    def get(self,type):
        result = self.task_queue[type]["queue_obj"].get_nowait()
        if result:
            return ast.literal_eval(result)
        else:
            return result

    def put(self,info,type):
        try:
            queue_info ={}
            for key in info:
                queue_info[key] = info[key]            
            print queue_info
            self.task_queue[type]["queue_obj"].put(queue_info)
            return True
        except Exception as e:
            print e
            return False
