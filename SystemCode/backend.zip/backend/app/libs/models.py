import time
import threading
import joblib
import plac
import random
import pathlib
import cytoolz
import numpy
import pandas as pd 
import keras
from keras.models import Sequential, model_from_json
from keras.layers import LSTM, Dense, Embedding, Bidirectional
from keras.layers import TimeDistributed
from keras.optimizers import Adam
from spacy.compat import pickle
from spacy.matcher import PhraseMatcher
import tensorflow as tf
import spacy
from deeppavlov import build_model, configs
import tensorflow as tf


path_vectors = "app/sa/en_vectors_web_lg/en_vectors_web_lg-2.1.0"
path_model = 'app/sa/model_lstm/'

class Singleton(object):
    _instance_lock = threading.Lock()

    def __init__(self):
        self.qamodel = build_model(configs.squad.squad, load_trained=True)
        self.chatbotmodel = joblib.load('finalized_model.sav')
        global graph
        graph = tf.get_default_graph()
        time.sleep(1)
        print("done")

    def load_nlp_model(self):
        nlp = spacy.load('en_core_web_sm',disable=['parser','ner'])
        nlp.add_pipe(nlp.create_pipe("sentencizer"))
        self.nlp = nlp

        print("done")
        nlp_sentiment = spacy.load(path_vectors)
        nlp_sentiment.add_pipe(nlp.create_pipe("sentencizer"))
        nlp_sentiment.add_pipe(SentimentAnalyser.load(nlp_sentiment, path_model, 100))
        print("done")
        
        self.nlp_sentiment = nlp_sentiment

    @classmethod
    def instance(cls, *args, **kwargs):
        with Singleton._instance_lock:
            if not hasattr(Singleton, "_instance"):
                Singleton._instance = Singleton(*args, **kwargs)
        return Singleton._instance

class SentimentAnalyser(object):
    
    @classmethod
    def load(cls, nlp, path, max_length):
        with open(path+"config.json") as file_:
            model = model_from_json(file_.read())
        with open(path+"model",'rb') as file_:
            lstm_weights = pickle.load(file_)
        embeddings = nlp.vocab.vectors.data
        model.set_weights([embeddings] + lstm_weights)
        return cls(model, max_length=max_length)

    def __init__(self, model, max_length=100):
            self._model = model
            self.max_length = max_length

    def __call__(self, doc):
            X = get_features([doc], self.max_length)
            y = self._model.predict(X)
            self.set_sentiment(doc, y)

    def pipe(self, docs, batch_size=1000):
        with graph.as_default():
            def get_features(docs, max_length):
                    docs = list(docs)
                    Xs = numpy.zeros((len(docs), max_length), dtype="int32")
                    for i, doc in enumerate(docs):
                        j = 0
                        for token in doc:
                            vector_id = token.vocab.vectors.find(key=token.orth)
                            if vector_id >= 0:
                                Xs[i, j] = vector_id
                            else:
                                Xs[i, j] = 0
                            j += 1
                            if j >= max_length:
                                break
                    return Xs
            for minibatch in cytoolz.partition_all(batch_size, docs):
                minibatch = list(minibatch)
                sentences = []
                for doc in minibatch:
                    sentences.extend(doc.sents)
           
                Xs = get_features(sentences, self.max_length)
                ys = self._model.predict(Xs)
                for sent, label in zip(sentences, ys):
                    sent.doc.sentiment += label 
                for doc in minibatch:
                    yield doc



    def set_sentiment(self, doc, y):
            doc.sentiment = float(y[0])
            
    def get_labelled_sentences(docs, doc_labels):
        labels = []
        sentences = []
        for doc, y in zip(docs, doc_labels):
            for sent in doc.sents:
                sentences.append(sent)
                labels.append(y)
        return sentences, numpy.asarray(labels, dtype="int32")

    def compile_lstm(embeddings, shape, settings):
        model = Sequential()
        model.add(
            Embedding(
                embeddings.shape[0],
                embeddings.shape[1],
                input_length=shape["max_length"],
                trainable=False,
                weights=[embeddings],
                mask_zero=True,
            )
        )
        model.add(TimeDistributed(Dense(shape["nr_hidden"], use_bias=False)))
        model.add(
            Bidirectional(
                LSTM(
                    shape["nr_hidden"],
                    recurrent_dropout=settings["dropout"],
                    dropout=settings["dropout"],
                )
            )
        )
        model.add(Dense(shape["nr_class"], activation="sigmoid"))
        model.compile(
            optimizer=Adam(lr=settings["lr"]),
            loss="binary_crossentropy",
            metrics=["accuracy"],
        )
        return model
