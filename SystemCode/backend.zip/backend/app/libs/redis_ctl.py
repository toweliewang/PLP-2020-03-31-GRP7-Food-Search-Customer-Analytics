# -*- coding:utf-8 -*-
import redis

from app.config.secure import REDIS_PASSWORD,REDIS_PORT,REDIS_URL,REDIS_KEY_VALUE_TIMEOUT

class RedisCtl(object):
    def __init__(self, **redis_kwargs):
       # redis的默认参数为：host='localhost', port=6379, db=0， 其中db为定义redis database的数量
       self.__db= redis.StrictRedis(host=REDIS_URL, port=REDIS_PORT,db=1)

    def saveData(self,key,data):
        self.__db.set(key,data)

    def saveData_Timeout(self,key,data,timeout=REDIS_KEY_VALUE_TIMEOUT):
        self.__db.setex(key,data, timeout)

    def getData(self,key):
        return self.__db.get(key)

    def checkData(self,key):
        if self.__db.exists(key):
          return True
        else:
          return False
    
    def deleteData(self,key):
        self.__db.delete(key)