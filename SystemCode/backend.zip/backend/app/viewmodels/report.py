from collections import OrderedDict

from flask import g
import numpy as np

from app.models.eatery import Eatery
from app.models.user import User
from app.models.report import Report
from app.models.report_item import ReportItem
from app.models.report_item_review import ReportItemReview

from app.libs.utils import datatime_format

from app.libs.utils import timestamp_to_data,datatime_format


class ReportDetail(object):

    report_types = ['service','food','price','environment']

    def __init__(self,report):
        self.overall_summary = report.overall_summary
        self.food_summary = report.food_summary
        self.report = report
        self.all_report = Report.get_all_report(report.e_id)
        self.overall_report = self.generate_overall_report()
        self.sentiment_report = self.generate_sentiment_report()
        self.splited_report = self.generate_splited_report()
        
    def generate_overall_report(self):
        _report = {}
        # 1 v all
        average_overall_score = (np.array([r.overall_score for r in self.all_report])).mean()
        _report['one_all'] = {
          'labels': [self.report.report_range,'All Time'],
          'data': [self.report.overall_score,average_overall_score]
        }
        # all
        _report['all'] = {
          'label': [r.report_range for r in self.all_report],
          'data':[r.overall_score for r in self.all_report]
        }
        return _report

    def generate_sentiment_report(self):
        _report = {}
        # 1
        _report['one'] = {}
        _report['one']['positive'] = []
        _report['one']['negative'] = []
        for _type in ['service','environment']:
          _item = ReportItem.get_for_report_singletype(_type,self.report.id)
          _report['one']['positive'].append(_item.positive) 
          _report['one']['negative'].append(_item.negative)

        _items = ReportItem.get_for_report_singletype_food('food',self.report.id)
        _food_positive = 0
        _food_negetive = 0
        for it in _items:
          _food_positive += it.positive
          _food_negetive += it.negative
        # price
        _report['one']['positive'].append(_food_positive) 
        _report['one']['negative'].append(_food_negetive)
        _item = ReportItem.get_for_report_singletype('price',self.report.id)
        _report['one']['positive'].append(_item.positive + _item.neutral) 
        _report['one']['negative'].append(_item.negative)
        # 2
        _report['all'] = {}
        _report['all']['label'] = []
        _report['all']['service'] = {}
        _report['all']['food'] = {}
        _report['all']['environment'] = {}
        _report['all']['price'] = {}
        for r in self.all_report:
          _report['all']['label'].append(r.report_range)
          for _type in ['service','environment']:
            _item = ReportItem.get_for_report_singletype(_type,r.id)
            if not 'positive' in _report['all'][_type]:
              _report['all'][_type]['positive'] = []
              _report['all'][_type]['positive'].append(_item.positive)
            else:            
              _report['all'][_type]['positive'].append(_item.positive)
            if not 'negative' in _report['all'][_type]:
              _report['all'][_type]['negative'] = []
              _report['all'][_type]['negative'].append(_item.negative)
            else:            
              _report['all'][_type]['negative'].append(_item.negative)
          # price
          _item = ReportItem.get_for_report_singletype('price',self.report.id)
          _report['all']['price']['positive'] = []
          _report['all']['price']['positive'].append(_item.positive + _item.neutral)
          _report['all']['price']['negative'] = []
          _report['all']['price']['negative'].append(_item.negative)

          # food
          _items = ReportItem.get_for_report_singletype_food('food',self.report.id)
          _report['all']['food']['positive'] = []
          _report['all']['food']['negative'] = []
          for it in _items:
            _report['all']['food']['positive'].append(it.positive) 
            _report['all']['food']['negative'].append(it.negative)
        
        
        return _report

    def generate_splited_report(self):
        _report = {}
        for _type in ['service','environment']:
          _item = ReportItem.get_for_report_singletype(_type,self.report.id)
          _report[_type] = {}
          _report[_type]['positive'] = {}
          _report[_type]['positive']['num']= _item.positive
          _report[_type]['positive']['review'] = ReportItemReview.get_report_review_by_riid('positive',_item.id)
          _report[_type]['negative'] = {}
          _report[_type]['negative']['num']= _item.negative
          _report[_type]['negative']['review'] = ReportItemReview.get_report_review_by_riid('negative',_item.id)
        
        # price report
        _item = ReportItem.get_for_report_singletype('price',self.report.id)
        _report['price'] = {}
        _report['price']['positive'] = {}
        _report['price']['positive']['num']= _item.positive
        _report['price']['positive']['review'] = ReportItemReview.get_report_review_by_riid('positive',_item.id)
        _report['price']['negative'] = {}
        _report['price']['negative']['num']= _item.negative
        _report['price']['negative']['review'] = ReportItemReview.get_report_review_by_riid('negative',_item.id)
        _report['price']['neutral'] = {}
        _report['price']['neutral']['num']= _item.neutral
        _report['price']['neutral']['review'] = ReportItemReview.get_report_review_by_riid('neutral',_item.id)
        print(_report['price'])

        # food report
        _items = ReportItem.get_for_report_singletype_food('food',self.report.id)
        _report['food'] = {}
        _report['food']['words'] = []
        _report['food']['review'] = []
        for it in _items:
          _report_item = {}
          _report_item['entity'] = it.entity
          _report_item['positive'] = {}
          _report_item['positive']['num']= it.positive
          _report_item['positive']['review'] = ReportItemReview.get_report_review_by_riid('positive',it.id)
          _report_item['negative'] = {}
          _report_item['negative']['num']= it.negative
          _report_item['negative']['review'] = ReportItemReview.get_report_review_by_riid('negative',it.id)
          _report['food']['review'].append(_report_item)
          _report['food']['words'].append({'name':it.entity,'value':it.positive+it.negative})



        return _report

    def keys(self):
        return ['overall_summary','food_summary','overall_report', 'sentiment_report','splited_report']

    def __getitem__(self, item):
        return getattr(self, item)




class ReportViewModel(object):

    report_types = ['service','food','price','environment']

    def __init__(self,report):
        self.id = report['id']
        self.create_time = datatime_format(report._create_time)
        self.e_id = report['e_id']
        self.report_range = report['report_range']
        self.report = ReportItem.get_for_report_types(self.report_types,report['id'])
        self.display_review = self.getdisplay_review()

    def getdisplay_review(self):
        _reviews = []
        for key,value in self.report.items():
            _reviews.extend([review.content for review in value['positive_review']])
            _reviews.extend([review.content for review in value['negative_review']])
        return _reviews

    def keys(self):
        return ['id', 'e_id','report_range','report','display_review','create_time']

    def __getitem__(self, item):
        return getattr(self, item)

class ReportCollection(object):
    def __init__(self):
        self.data = []

    def fill(self, reports):
        self.data = [ReportViewModel(report) for report in reports]