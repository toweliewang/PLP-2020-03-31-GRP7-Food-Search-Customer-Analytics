from collections import OrderedDict

from flask import g

from app.models.eatery import Eatery
from app.models.user import User
from app.models.report import Report
from app.viewmodels.report import ReportViewModel

class EateryViewModel(object):
    def __init__(self,eatery):
        self.id = eatery['id']
        owner = User.get(id=eatery['u_id'])
        if owner:
            self.owner = {
                'id' : owner.id,
                'name' : owner.username
            }
        else:
            self.owner = {}
        self.link = eatery['link']
        self.cuisine = eatery['cuisine']
        self.rating = eatery['rating']
        self.name = eatery['name']
        self.address = eatery['address']
        self.phone = eatery['phone']
        self.from_info = eatery['from_info']
        self.description = eatery['description']
        self.coordinate_lng = eatery['coordinate_lng']
        self.coordinate_lat = eatery['coordinate_lat']
        report = Report.get_latest_report(eatery['id'])
        if report:
          self.report = ReportViewModel(report)
        else:
          self.report = {}
        

    def keys(self):
        return ['id', 'owner','link','cuisine','rating','name','address',
                'phone','from_info','description','coordinate_lng','coordinate_lat','report']

    def __getitem__(self, item):
        return getattr(self, item)

class EateryCollection(object):
    def __init__(self):
        self.data = []

    def fill(self, eateries):
        self.data = [EateryViewModel(eatery) for eatery in eateries]


class EateryViewModel_Simple(object):
    def __init__(self,eatery):
        self.id = eatery['id']
        self.value = eatery['name']

    def keys(self):
        return ['id', 'value']

    def __getitem__(self, item):
        return getattr(self, item)

class EateryCollection_Simple(object):
    def __init__(self):
        self.data = []

    def fill(self, eateries):
        self.data = [EateryViewModel_Simple(eatery) for eatery in eateries]
