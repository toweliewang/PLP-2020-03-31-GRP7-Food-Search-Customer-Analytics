from flask import jsonify
from flask_jwt_extended import get_current_user
from lin import group_required, login_required, route_meta
from lin.exception import Success
from lin.redprint import Redprint

from app.libs.error_code import EateryNotFound, NotFound
from app.models.eatery import Eatery
from app.models.review import Review
from app.validators.forms import (BookSearchForm, CreateOrUpdateBookForm,
                                  EaterySearchForm, EaterySelectForm)
from app.viewmodels.eatery import EateryCollection_Simple,EateryCollection

from app.models.report import Report
from app.models.report_item import ReportItem

from app.viewmodels.report import ReportCollection,ReportViewModel,ReportDetail

report_api = Redprint('report')

from app.models.report_item_review import ReportItemReview


# 这与真实的情况是一致的，因为一般的情况下，重要的接口需要被保护，重要的消息才需要推送
@report_api.route('/list/<eid>', methods=['GET'])
@login_required
def get_eateris(eid):
    reports = Report.get_all_report(eid=eid)
    reportCollection = ReportCollection()
    reportCollection.fill(reports)
    return jsonify(reportCollection.data)

@report_api.route('/getlatest/<eid>', methods=['GET'])
@login_required
def get_latest_report(eid):
    report = Report.get_latest_report(eid=eid)
    reportviewmodel = ReportViewModel(report)
    return jsonify(reportviewmodel)

@report_api.route('/detail/<rid>', methods=['GET'])
@login_required
def get_report_detail(rid):
    report = Report.get(id=rid)
    reportdetail = ReportDetail(report)
    return jsonify(reportdetail)


# @eatery_api.route('/list', methods=['GET'])
# @login_required
# def get_eateries():
#     eatery_sql = Eatery.get_all()
#     eateryCollection = EateryCollection()
#     eateryCollection.fill(eatery_sql)
#     return jsonify(eateryCollection.data)



# @eatery_api.route('/search', methods=['GET'])
# def get_eateriesbyname():
#     form = EaterySearchForm().validate_for_api() 
#     eatery_sql = Eatery.search_by_keywords(form.q.data)
#     eateryCollection = EateryCollection()
#     eateryCollection.fill(eatery_sql)
#     return jsonify(eateryCollection.data)

# @eatery_api.route('/searchbycuisine', methods=['GET'])
# def get_eateriesbycuisine():
#     form = EaterySearchForm().validate_for_api() 
#     eatery_sql = Eatery.search_by_cuisine(int(form.q.data))
#     eateryCollection = EateryCollection()
#     eateryCollection.fill(eatery_sql)
#     return jsonify(eateryCollection.data)

# @eatery_api.route('/list/<uid>', methods=['GET'])
# @login_required
# def get_eateriesbyuid(uid):
#     eatery_sql = Eatery.get_all_uid(uid)
#     eateryCollection = EateryCollection()
#     eateryCollection.fill(eatery_sql)
#     return jsonify(eateryCollection.data)

# @eatery_api.route('/simplesearch', methods=['GET'])
# @login_required
# def get_simplesearch():
#     eateries_sql = Eatery.get_simple()
#     eateries_collection = EateryCollection_Simple()
#     eateries_collection.fill(eateries_sql)
    
#     return jsonify(eateries_collection.data)

# @eatery_api.route('/select', methods=['POST'])
# @login_required
# def get_select():
#     form = EaterySelectForm().validate_for_api()

#     user = get_current_user()

#     if Eatery.update_uid(form.eid.data,user.id):
#         return jsonify(Eatery.get_detail(form.eid.data))
#     else:
#         return EateryNotFound()





# @book_api.route('', methods=['GET'])
# @login_required
# def get_books():
#     books = Book.get_all()
#     return jsonify(books)


# @book_api.route('/search', methods=['GET'])
# def search():
#     form = BookSearchForm().validate_for_api()
#     books = Book.search_by_keywords(form.q.data)
#     return jsonify(books)


# @book_api.route('', methods=['POST'])
# def create_book():
#     form = CreateOrUpdateBookForm().validate_for_api()
#     Book.new_book(form)
#     return Success(msg='新建图书成功')


# @book_api.route('/<bid>', methods=['PUT'])
# def update_book(bid):
#     form = CreateOrUpdateBookForm().validate_for_api()
#     Book.edit_book(bid, form)
#     return Success(msg='更新图书成功')


# @book_api.route('/<bid>', methods=['DELETE'])
# @route_meta(auth='删除图书', module='图书')
# @group_required
# def delete_book(bid):
#     Book.remove_book(bid)
#     return Success(msg='删除图书成功')
