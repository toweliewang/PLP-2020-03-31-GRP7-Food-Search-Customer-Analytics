"""
    :copyright: © 2019 by the Lin team.
    :license: MIT, see LICENSE for more details.
"""

from flask import Blueprint
from app.api.v1 import eatery
from app.api.v1 import reivew
from app.api.v1 import report
from app.api.v1 import chatbot

def create_v1():
    bp_v1 = Blueprint('v1', __name__)
    from app.libs.models import Singleton
    single = Singleton.instance()
    single.load_nlp_model()
    eatery.eatery_api.register(bp_v1)
    reivew.review_api.register(bp_v1)
    report.report_api.register(bp_v1)
    chatbot.chatbot_api.register(bp_v1)
    return bp_v1
