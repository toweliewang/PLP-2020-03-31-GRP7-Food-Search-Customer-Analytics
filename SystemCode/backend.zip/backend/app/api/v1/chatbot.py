"""
 Create by jiachenx on 2019/3/11
"""
from flask import jsonify,request
from lin import route_meta, group_required, login_required
from flask_jwt_extended import create_access_token, get_jwt_identity, get_current_user, \
    create_refresh_token, verify_jwt_refresh_token_in_request
from lin.exception import Success
from lin.redprint import Redprint

from app.chatbot.Chatbot import Chatbot
import json
from flask_assistant import ask, tell, event, build_item
import os

from app.libs.redis_ctl import RedisCtl
import json
import random
import re
import joblib

from app.models.entity import Entity
from app.models.phase import Phase
from app.models.feedback import Feedback
from app.models.user import User

chatbot_api = Redprint('chatbot')

@chatbot_api.route('/detect/<uid>', methods=['GET'])
def detect(uid):
    _chatbot = Chatbot()
    session_id = request.args.get('session')
    # session_id = "123444"
    queryInput = json.loads(s=request.args.get('queryInput'))['text']['text'].strip()
    # if isinstance(queryInput, str):
    #   queryInput = queryInput.strip()
    # if isinstance(queryInput, list):
    #   _temp = []
    #   for q in queryInput:
    #     _temp.append(q.strip())
    #   queryInput = _temp
    inputText = {'queryText': queryInput}
    # response = getMuseumIntroDao("museum")
    print(queryInput)
    user = User.get(id=uid)
    response = _chatbot.getChartbotResponse(queryInput,session_id,user.username)
    print(response._response)
    if queryInput == "feedback" or queryInput == 'recommendation':
        result = {"queryResult":dict("",**response._response)}
    else:
        result = {"queryResult":dict(inputText,**response._response)}
    return jsonify(result)


@chatbot_api.route('/check_feedback/', methods=['GET'])
@login_required
def check_feedback():
    user = get_current_user()
    feedback = Feedback.check_has_feedback(user.id)
    result = {}
    if feedback:
        result['status'] = 1
    else:
        result['status'] = 0
    return jsonify(result)

@chatbot_api.route('/check_recommendation/', methods=['GET'])
@login_required
def check_recommendation():
    user = get_current_user()
    feedback = Feedback.check_has_feedback(user.id)
    recommendation = Chatbot.check_has_recommendation(user.username)
    result = {}
    print("recommendation")
    if not feedback and recommendation:
        result['status'] = 1
    else:
        result['status'] = 0
    return jsonify(result)