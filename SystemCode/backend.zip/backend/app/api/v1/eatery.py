from flask import jsonify
from flask_jwt_extended import get_current_user
from lin import group_required, login_required, route_meta
from lin.exception import Success
from lin.redprint import Redprint

from app.libs.error_code import EateryNotFound, NotFound
from lin.exception import NotFound, Success, Failed, RepeatException, ParameterException
from app.models.eatery import Eatery
from app.models.review import Review
from app.models.report import Report
from app.validators.forms import (BookSearchForm, CreateOrUpdateBookForm,
                                  EaterySearchForm, EaterySelectForm)
from app.viewmodels.eatery import EateryCollection_Simple,EateryCollection,EateryViewModel

eatery_api = Redprint('eatery')


# 这与真实的情况是一致的，因为一般的情况下，重要的接口需要被保护，重要的消息才需要推送
@eatery_api.route('/<eid>', methods=['GET'])
@login_required
def get_eatery(eid):
    eatery_sql = Eatery.get_detail(eid)
    eatery = EateryViewModel(eatery_sql)
    return jsonify(eatery)

@eatery_api.route('/list', methods=['GET'])
@login_required
def get_eateries():
    eatery_sql = Eatery.get_all()
    eateryCollection = EateryCollection()
    eateryCollection.fill(eatery_sql)
    return jsonify(eateryCollection.data)

@eatery_api.route('/search', methods=['GET'])
def get_eateriesbyname():
    form = EaterySearchForm().validate_for_api() 
    eatery_sql = Eatery.search_by_keywords(form.q.data)
    eateryCollection = EateryCollection()
    eateryCollection.fill(eatery_sql)
    return jsonify(eateryCollection.data)

@eatery_api.route('/searchcuisine_all', methods=['GET'])
def get_searchcuisine_all():
    form = EaterySearchForm().validate_for_api() 
    eatery_sql = Eatery.search_by_cuisine_all(form.q.data)
    eateryCollection = EateryCollection()
    eateryCollection.fill(eatery_sql)
    return jsonify(eateryCollection.data)

@eatery_api.route('/searchbycuisine', methods=['GET'])
def get_eateriesbycuisine():
    form = EaterySearchForm().validate_for_api() 
    eatery_sql = Eatery.search_by_cuisine(int(form.q.data))
    eateryCollection = EateryCollection()
    eateryCollection.fill(eatery_sql)
    return jsonify(eateryCollection.data)

@eatery_api.route('/list/<uid>', methods=['GET'])
@login_required
def get_eateriesbyuid(uid):
    eatery_sql = Eatery.get_all_uid(uid)
    eateryCollection = EateryCollection()
    eateryCollection.fill(eatery_sql)
    return jsonify(eateryCollection.data)

@eatery_api.route('/simplesearch', methods=['GET'])
@login_required
def get_simplesearch():
    eateries_sql = Eatery.get_simple()
    eateries_collection = EateryCollection_Simple()
    eateries_collection.fill(eateries_sql)
    
    return jsonify(eateries_collection.data)

@eatery_api.route('/simplesearch/all', methods=['GET'])
@login_required
def get_simplesearch_all():
    eateries_sql = Eatery.get_all()
    eateries_collection = EateryCollection_Simple()
    eateries_collection.fill(eateries_sql)
    
    return jsonify(eateries_collection.data)

@eatery_api.route('/getallcuisine',methods=['GET'])
@login_required
def get_all_cuisine():
    cuisines = Eatery.get_all_cuisine()
    result = {
      'cuisines':cuisines
    }
    return jsonify(result)

@eatery_api.route('/select', methods=['POST'])
@login_required
def get_select():
    form = EaterySelectForm().validate_for_api()

    user = get_current_user()
    try:
      if Eatery.update_uid(form.eid.data,user.id):
        Report.clear_report(form.eid.data)
        Report.generate(form.eid.data)
        return Success()
      else:
        return Success(msg='error')
    except Exception as e:
      raise(e)
      Eatery.update_uid(form.eid.data,None)
      Report.clear_report(form.eid.data)
      return Success(msg='error')





# @book_api.route('', methods=['GET'])
# @login_required
# def get_books():
#     books = Book.get_all()
#     return jsonify(books)


# @book_api.route('/search', methods=['GET'])
# def search():
#     form = BookSearchForm().validate_for_api()
#     books = Book.search_by_keywords(form.q.data)
#     return jsonify(books)


# @book_api.route('', methods=['POST'])
# def create_book():
#     form = CreateOrUpdateBookForm().validate_for_api()
#     Book.new_book(form)
#     return Success(msg='新建图书成功')


# @book_api.route('/<bid>', methods=['PUT'])
# def update_book(bid):
#     form = CreateOrUpdateBookForm().validate_for_api()
#     Book.edit_book(bid, form)
#     return Success(msg='更新图书成功')


# @book_api.route('/<bid>', methods=['DELETE'])
# @route_meta(auth='删除图书', module='图书')
# @group_required
# def delete_book(bid):
#     Book.remove_book(bid)
#     return Success(msg='删除图书成功')
