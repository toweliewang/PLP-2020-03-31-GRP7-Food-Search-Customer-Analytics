# -*- coding: utf-8 -*-
from py2neo import Node, Graph, Relationship
from py2neo import NodeMatcher,RelationshipMatcher
from configparser import ConfigParser


def config(filename='app/neo4j_graph/database.ini', section='neo4j'):
    paser = ConfigParser()
    paser.read(filename)
    db={}
    if paser.has_section(section):
        params=paser.items(section)
        for param in params:
            db[param[0]]=param[1]
    else:
        raise Exception('Section {0} not found in the {1} file'.format(section,filename))
    return db


class DataToNeo4j(object):

    def __init__(self):
        """establish link to neo4j"""
        # params=config()
        link = Graph("bolt://neo4j4ca:7687",auth=("neo4j","test"))
        self.graph = link
        # label and properties
        # self.restaurant=['']
        # self.graph.delete_all()

    def create_node(self, node_label, node_properties):
        """create node with properties, node_label: string, node_property: dict"""
        node=Node(node_label,**node_properties)
        self.graph.create(node)

    def create_relation(self, relation_dict):
        """create relationship with properties"""
        relation_properties=dict((key,value) for key,value in relation_dict.items() if key!='name1' and key!='relationship' and key!='name2')

        matcher = NodeMatcher(self.graph)
        start_node=matcher.match(name=relation_dict['name1']).first()
        end_node=matcher.match(name=relation_dict['name2']).first()

        relation_type = relation_dict['relationship']
        if start_node != None and end_node != None:
            relation=Relationship(start_node,relation_type,end_node)
            if relation_dict['relationship']=='include':
                dis=relation_dict['distance']
                prop={'distance':dis}
                relation = Relationship(start_node, relation_type, end_node,**prop)
            if relation_dict['relationship'] == 'exist':
                tt = relation_dict['taste']
                prop = {'taste': tt}
                relation = Relationship(start_node, relation_type, end_node, **prop)
            if relation_dict['relationship'] == 'ask':
                ct = relation_dict['count']
                prop={'count':ct}
                relation = Relationship(start_node, relation_type, end_node, **prop)
            self.graph.create(relation)

    def nm(self):
        return NodeMatcher(self.graph)

    def rm(self):
        return RelationshipMatcher(self.graph)

    # def create_relation(self, df_data):
    #     """建立联系"""
    #
    #     m = 0
    #     for m in range(0, len(df_data)):
    #         try:
    #             rel = Relationship(self.graph.find_one(label=self.invoice_name, property_key='name', property_value=df_data['name'][m]),
    #                                df_data['relation'][m], self.graph.find_one(label=self.invoice_value, property_key='name',
    #                                property_value=df_data['name2'][m]))
    #             self.graph.create(rel)
    #         except AttributeError as e:
    #             print(e, m)
