from DataToNeo4j import config
from py2neo import Node, Graph, Relationship
from py2neo import NodeMatcher


params=config()
graph = Graph(**params)
matcher = NodeMatcher(graph)


def searchForRestaurant(cuisine, food, taste, location):

    node = matcher.match(name=food).first()
    return node


