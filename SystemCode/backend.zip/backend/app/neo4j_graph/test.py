from function_api import create_user,query_res,query_user,user_rel,filter_res

# create_user(26)

# ------------------ scenario 1: cuisine, area ----------------------#
# query={'area':'orchard'}
# result1=query_res(**query)
# print(f'find {len(result1)} restaurants:')
# for i in range(len(result1)):
#     print(result1[i])
#
#
# query={'cuisine':'asian'}
# result=query_res(**query)
# print(f'find {len(result)} restaurants:')
# for i in range(len(result)):
#     print(result[i])
# #
# #
# # #query by two conditions example
# combine=filter_res(result1,result)
# if combine is not None:
#     print(f'find {len(combine)} restaurants:')
#     for i in range(len(combine)):
#         print(combine[i])
# else:
#     print("no restaurant meet all the conditions")


# ------------------- scenario 2: taste, food, mrt ----------------------#
# query={'taste':'fresh','food':'crab'}
# result=query_res(**query)
# print(f'find {len(result)} restaurants:')
# for i in range(len(result)):
#     print(result[i])
#
# query={'mrt':'orchard mrt station'}
# result1=query_res(**query)
# print(f'find {len(result1)} restaurants:')
# for i in range(len(result1)):
#     print(result1[i])
#
# combine=filter_res(result1,result)
# if combine is not None:
#     print(f'find {len(combine)} restaurants:')
#     for i in range(len(combine)):
#         print(combine[i])
# else:
#     print("no restaurant meet all the conditions")


# query={'mrt':'promenade mrt station'}
# result=query_res(**query)
# print(f'find {len(result)} restaurants:')
# for i in range(len(result)):
#     print(result[i])

# query={'area':'downtown core'}
# result=query_res(**query)
# print(f'find {len(result)} restaurants:')
# for i in range(len(result)):
#     print(result[i])

# ------------------- scenario 3.1: query user reference ----------------------#
# id=123456000
# result,counts,type=query_user(id)
# print(f'find {len(result)} reference:')
# for i in range(len(result)):
#     print(result[i])
# print(counts)
# print(type)


# ------------------- scenario 3.2: add user reference ----------------------#
id=123456000
ref={'food':'lobster tail'}
user_rel(id,**ref)

# id=123456000
# ref={'mrt':'Botanic Gardens MRT Station'}
# user_rel(id,**ref)

# id=123456000
# ref={'area':'Ang Mo Kio'}
# user_rel(id,**ref)

# ------------------- error scenario: random search  ----------------------#
# for one condition query, if can't find, just return an empty list
# query={'food':'abcdefg'}
# result=query_res(**query)
# print(type(result))

# for query one user who have no reference, just return an empty list
# id=1
# result,counts,utype=query_user(id)
# print(counts)
