from openpyxl import load_workbook
from DataToNeo4j import DataToNeo4j
from GetData import data_extraction,relation_extraction


d2n=DataToNeo4j()

nodefp='lower_NodeData.xlsx'
res,food,mrt,area,user=data_extraction(nodefp)
for i in range(len(res)):
    d2n.create_node('restaurant',res[i])
for i in range(len(food)):
    d2n.create_node('food',food[i])
for i in range(len(mrt)):
    d2n.create_node('mrt',mrt[i])
for i in range(len(area)):
    d2n.create_node('area', area[i])
for i in range(len(user)):
    d2n.create_node('user',user[i])

relfp='lower_RelData.xlsx'
rel_sheet=load_workbook(relfp).sheetnames
for i in range(len(rel_sheet)):
    records=relation_extraction(relfp,rel_sheet[i])
    for j in range(len(records)):
        d2n.create_relation(records[j])
    print("finish",rel_sheet[i])
