from openpyxl import load_workbook
from DataToNeo4j import DataToNeo4j


def data_extraction(filepath):
    wb=load_workbook(filepath)
    sheets = wb.sheetnames
    print(sheets)

    res_records = []
    food_records = []
    mrt_records = []
    area_records=[]
    user_records = []

    for i in range(len(sheets)):
        data = wb[sheets[i]]
        properties = []
        for j in range(len(data[1])):
            properties.append(data[1][j].value)
        print(properties)

        rows = data.max_row
        print(rows)
        records = []
        for r in range(rows - 1):
            record = {}
            for c in range(len(properties)):
                record[properties[c]] = data.cell(row=r + 2, column=c + 1).value
            records.append(record)

        if i == 0:
            res_records = records
        elif i == 1:
            food_records = records
        elif i == 2:
            mrt_records = records
        elif i == 3:
            area_records = records
        else:
            user_records = records
    return res_records,food_records,mrt_records,area_records,user_records


def relation_extraction(filepath,sheetname):
    wb = load_workbook(filepath)
    # sheets = wb.sheetnames
    # print(sheets)
    # for i in range(len())
    data=wb[sheetname]
    key=[]
    for j in range(len(data[1])):
        key.append(data[1][j].value)
    print(key)

    rows = data.max_row
    print(rows)
    relrecords = []
    for r in range(rows - 1):
        record = {}
        for c in range(len(key)):
            record[key[c]] = data.cell(row=r + 2, column=c + 1).value
        relrecords.append(record)

    return relrecords





# d2n=DataToNeo4j()
#
# nodefp='/Users/lin/Documents/plpCA/data/draft_NodeData.xlsx'
# res,food,mrt,area,user=data_extraction(nodefp)
# for i in range(len(res)):
#     d2n.create_node('restaurant',res[i])
# for i in range(len(food)):
#     d2n.create_node('food',food[i])
# for i in range(len(mrt)):
#     d2n.create_node('mrt',mrt[i])
# for i in range(len(area)):
#     d2n.create_node('area', area[i])
# for i in range(len(user)):
#     d2n.create_node('user',user[i])
#
# relfp='/Users/lin/Documents/plpCA/data/draft_RelData3_8.xlsx'
# rel_sheet=load_workbook(relfp).sheetnames
# for i in range(len(rel_sheet)):
#     records=relation_extraction(relfp,rel_sheet[i])
#     for j in range(len(records)):
#         d2n.create_relation(records[j])
#     print("finish",i)

