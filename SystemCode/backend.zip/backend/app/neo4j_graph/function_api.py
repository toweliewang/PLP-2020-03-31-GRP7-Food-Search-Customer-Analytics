from app.neo4j_graph.DataToNeo4j import DataToNeo4j
from py2neo import Node, Graph, Relationship
from py2neo import NodeMatcher
from py2neo import RelationshipMatcher

d2n=DataToNeo4j()
nm=d2n.nm()
rm=d2n.rm()


def create_user(id):
    prop={'name':id}
    node=nm.match('user',name=id).first()
    if node is None:
        d2n.create_node('user', prop)
        print('finish create user')
    else:
        print('This user is already exist.')

#expect parameter type: dictionary
def query_res(**query):
    res_list=[]
    if 'name' in query:
        node=nm.match('restaurant',name=query['name']).first()
        if node is not None:
            res_list.append(node)
            return res_list
            # return dict(node)

    elif 'cuisine' in query:
        nodes = d2n.graph.run("match(res:restaurant) where res.cuisine =~'.*%s.*' return res"%query['cuisine']).data()
        # nmobj=nm.match('restaurant',cuisine=query['cuisine'])
        # nodes=list(nmobj)
        if nodes is not None:
            for i in range(len(nodes)):
                # res_list.append(dict(nodes[i]))
                res_list.append(dict(nodes[i]['res']))
            return res_list

    elif 'food' in query:
        xry=d2n.graph.run("match (x)-[r:exist]-(y) where x.name='%s' return x,r,y" %query['food']).data()
        for i in range(len(xry)):
            res_list.append(dict(xry[i]['y']))
        return res_list

    elif 'mrt' in query:
        xry = d2n.graph.run("match (x)-[r:include]-(y) where x.name='%s' return x,r,y" % query['mrt']).data()
        for i in range(len(xry)):
            temp = dict(xry[i]['y'])
            temp['distance'] = dict(xry[i]['r'])['distance']
            res_list.append(temp)
        return res_list

    elif 'area' in query:
        xry = d2n.graph.run("match (x)-[r:cover]-(y) where x.name='%s' return x,r,y" % query['area']).data()
        mrts = []
        for i in range(len(xry)):
            mrts.append(dict(xry[i]['y']))
        print('the number of mrt stations in this area:',len(mrts))
        for i in range(len(mrts)):
            xry = d2n.graph.run("match (x)-[r:include]-(y) where x.name='%s' return x,r,y" % dict(mrts[i])['name']).data()
            for i in range(len(xry)):
                res_list.append(dict(xry[i]['y']))
            return res_list

    elif 'taste' in query:
        if 'food' not in query:
            print('please offer the food name for query')
        else:
            xry = d2n.graph.run("match (x)-[r:exist]-(y) where x.name='%s' return x,r,y" % query['food']).data()
            res_list=[]
            for i in range(len(xry)):
                if dict([xry[i]['r']])['taste']==query['taste']:
                    res_list.append(dict(xry[i]['y']))
            return res_list

        #     nodes=nm.match('mrt',name=mrts[i]['name'])
        #     for node in nodes:
        #         if node is not None:
        #             res_list.append(dict(node))
        # return res_list
    # else:
    #     print('No restaurant matched.')
    #     return None

def query_user(id):
    xry=d2n.graph.run("match (x)-[r:ask]-(y) where x.name='%s' return x,r,y" % id).data()
    ref = []
    count=[]
    type=[]
    if xry is not None:
        for i in range(len(xry)):
            ref.append(dict(xry[i]['y']))
            count.append(dict(xry[i]['r']))
            type.append(xry[i]['y'].labels)
        return ref,count,type
    else:
        # raise Exception("This user haven't asked before.")
        return None

def user_rel(id,**ref):
    if 'food' in ref:
        xry = d2n.graph.run(f"match (x)-[r:ask]-(y) where x.name='{id}' and y.name='{ref['food']}' return x,r,y").data()
        if len(xry)!=0:
            temp = xry[0]['r']['count']
            temp = temp + 1
            d2n.graph.run(f"match (x)-[r:ask]-(y) where x.name='{id}' and y.name='{ref['food']}' delete r")
            snode = nm.match('user', name=id).first()
            relation_type='ask'
            enode = nm.match('food', name=ref['food']).first()
            relation = Relationship(snode, relation_type, enode)
            relation['count']=temp
            d2n.graph.create(relation)
            print('update count')
        else:
            start_node=nm.match('user',name=id).first()
            relation_type='ask'
            end_node=nm.match('food',name=ref['food']).first()
            relation=Relationship(start_node,relation_type,end_node)
            relation['count']=1
            d2n.graph.create(relation)
            print('create the new relation')

    elif 'restaurant' in ref:
        xry = d2n.graph.run(f"match (x)-[r:ask]-(y) where x.name='{id}' and y.name='{ref['restaurant']}' return x,r,y").data()
        if len(xry) != 0:
            temp = xry[0]['r']['count']
            temp = temp + 1
            d2n.graph.run(f"match (x)-[r:ask]-(y) where x.name='{id}' and y.name='{ref['restaurant']}' delete r")
            snode = nm.match('user', name=id).first()
            relation_type = 'ask'
            enode = nm.match('restaurant', name=ref['restaurant']).first()
            relation = Relationship(snode, relation_type, enode)
            relation['count'] = temp
            d2n.graph.create(relation)
            print('update count')
        else:
            start_node = nm.match('user', name=id).first()
            relation_type = 'ask'
            end_node = nm.match('restaurant', name=ref['restaurant']).first()
            relation = Relationship(start_node, relation_type, end_node)
            relation['count'] = 1
            d2n.graph.create(relation)
            print('create the new relation')

        # xry=d2n.graph.run("match (x)-[r:ask]-(y) where x.id='%s' return x,r,y"%id).data()
        # if xry is not None:
        #     for i in range(len(xry)):
        #         xry[i]['r'].count+=1
        # else:
        #     start_node=nm.match('user',id=id).first()
        #     relation_type='ask'
        #     end_node=nm.match('restaurant',name=ref['restaurant']).first()
        #     relation=Relationship(start_node,relation_type,end_node)
        #     d2n.graph.create(relation)
    elif 'mrt' in ref:
        xry = d2n.graph.run(
            f"match (x)-[r:ask]-(y) where x.name='{id}' and y.name='{ref['mrt']}' return x,r,y").data()
        if len(xry) != 0:
            temp = xry[0]['r']['count']
            temp = temp + 1
            d2n.graph.run(f"match (x)-[r:ask]-(y) where x.name='{id}' and y.name='{ref['mrt']}' delete r")
            snode = nm.match('user', name=id).first()
            relation_type = 'ask'
            enode = nm.match('mrt', name=ref['mrt']).first()
            relation = Relationship(snode, relation_type, enode)
            relation['count'] = temp
            d2n.graph.create(relation)
            print('update count')
        else:
            start_node = nm.match('user', name=id).first()
            relation_type = 'ask'
            end_node = nm.match('mrt', name=ref['mrt']).first()
            relation = Relationship(start_node, relation_type, end_node)
            relation['count'] = 1
            d2n.graph.create(relation)
            print('create the new relation')
    elif 'area' in ref:
        xry = d2n.graph.run(
            f"match (x)-[r:ask]-(y) where x.name='{id}' and y.name='{ref['area']}' return x,r,y").data()
        if len(xry) != 0:
            temp = xry[0]['r']['count']
            temp = temp + 1
            d2n.graph.run(f"match (x)-[r:ask]-(y) where x.name='{id}' and y.name='{ref['area']}' delete r")
            snode = nm.match('user', name=id).first()
            relation_type = 'ask'
            enode = nm.match('area', name=ref['area']).first()
            relation = Relationship(snode, relation_type, enode)
            relation['count'] = temp
            d2n.graph.create(relation)
            print('update count')
        else:
            start_node = nm.match('user', name=id).first()
            relation_type = 'ask'
            end_node = nm.match('area', name=ref['area']).first()
            relation = Relationship(start_node, relation_type, end_node)
            relation['count'] = 1
            d2n.graph.create(relation)
            print('create the new relation')


def filter_res(dl1, dl2):
    if dl1 is not None and dl2 is not None:
        res_list=[]
        for i in range(len(dl1)):
            for j in range(len(dl2)):
                if dl1[i]['name'] == dl2[j]['name']:
                    res_list.append(dl2[j])
        if len(res_list) is not 0:
            return res_list
        else:
            # raise Exception("no restaurant meet all the conditions")
            return None
    else:
        return None
        # raise Exception('Dictionary list1 or list2 is None.')




# test=d2n.graph.run("match (x)-[r:include]-(y) where x.name='Little India MRT Station' return x,r,y").data()
# print(dict(test[0]['y']))
