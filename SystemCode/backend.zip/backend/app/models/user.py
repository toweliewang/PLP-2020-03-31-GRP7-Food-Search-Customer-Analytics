from lin.core import User as _User
from lin.exception import NotFound, ParameterException,APIException, UnknownException, AuthFailed
from sqlalchemy import Column, String, Integer


class User(_User):
    gender = Column(Integer, nullable=False)
    age = Column(Integer,nullable=False)
    phone = Column(String(20), unique=True)

    @classmethod
    def get_detail(cls, uid):
        user = cls.query.filter_by(id=uid, delete_time=None).first()
        if user is None:
            raise NotFound(msg='no user')
        return user

    @classmethod
    def verify(cls, username, password):
        user = cls.query.filter_by(username=username).first()
        if user is None or user.delete_time is not None:
            raise NotFound(msg="Not Existed")
        if not user.check_password(password):
            raise ParameterException(msg='Wrong Password')
        if not user.is_active:
            raise AuthFailed(msg='Not actived')
        return user
