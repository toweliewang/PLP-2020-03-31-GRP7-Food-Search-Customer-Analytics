"""
    :copyright: © 2019 by the Lin team.
    :license: MIT, see LICENSE for more details.
"""
from lin.exception import NotFound, ParameterException
from lin.interface import InfoCrud as Base
from sqlalchemy import Column, String, Integer, orm, ForeignKey
from sqlalchemy.orm import relationship, backref
from sqlalchemy.dialects.mysql import LONGTEXT, DATE


class SupportComment(Base):

    __tablename__ = 'support_comment'

    id = Column(Integer, primary_key=True, autoincrement=True)
    ri_id = Column(Integer, ForeignKey('report_items.id'))
    comment = Column(LONGTEXT, nullable=False)

    @classmethod
    def get_detail(cls, scid):
        supportcomment = cls.query.filter_by(id=scid, delete_time=None).first()
        if supportcomment is None:
            raise NotFound(msg='Not found')
        return supportcomment

    @classmethod
    def get_all_for_reportitem(cls,ri_id):
        supportcomment = cls.query.filter_by(ri_id=ri_id,delete_time=None).all()
        if not supportcomment:
            raise NotFound(msg='Not found')
        return supportcomment

    # @classmethod
    # def search_by_keywords(cls, q):
    #     enteries = cls.query.filter(Entery.name.like('%' + q + '%'), Entery.delete_time == None).all()
    #     if not enteries:
    #         raise EnteryNotFound()
    #     return enteries

    @classmethod
    def new_support_comment(cls, form):
        # location need process

        SupportComment.create(
            ri_id = form.ri_id.data,
            comment = form.comment.data,
            commit=True
        )
        return True