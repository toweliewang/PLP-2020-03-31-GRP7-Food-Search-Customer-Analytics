"""
    :copyright: © 2019 by the Lin team.
    :license: MIT, see LICENSE for more details.
"""
from lin.exception import NotFound, ParameterException
from lin.interface import InfoCrud as Base
from sqlalchemy import Column, String, Integer, orm, ForeignKey
from sqlalchemy.orm import relationship, backref
from sqlalchemy.dialects.mysql import LONGTEXT, DATE

from app.libs.error_code import ReportNotFound

from app.libs.utils import date_to_timestamp

from app.models.user import User

from lin import db


class Feedback(Base):

    __tablename__ = 'feedback'

    id = Column(Integer, primary_key=True, autoincrement=True)
    u_id = Column(Integer, ForeignKey('lin_user.id'))
    eatery_name = Column(String(200), nullable=False)
    read = Column(Integer, nullable=False,server_default='0')

    @classmethod
    def check_has_feedback(cls,u_id):
        feedback = Feedback.query.filter_by(u_id=u_id,read=0,delete_time=None).first()
        if feedback:
            return feedback
        else:
            return None

    @classmethod
    def add_feedback(cls,u_id,eatery_name):
        user = User.get(username=u_id)
        with db.auto_commit():
            feedback = Feedback()
            feedback.u_id = user.id
            feedback.eatery_name = eatery_name
            db.session.add(feedback)

    @classmethod
    def get_feedback(cls,u_id):
        user = User.query.filter_by(username=u_id).first()
        feedback = Feedback.query.filter_by(u_id=user.id,delete_time=None,read=0).first()
        feedback.update(
            read=1,
            commit=True
        )
        return True
