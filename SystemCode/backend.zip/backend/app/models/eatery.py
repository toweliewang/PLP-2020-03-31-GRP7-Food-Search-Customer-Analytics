"""
    :copyright: © 2019 by the Lin team.
    :license: MIT, see LICENSE for more details.
"""
from lin.exception import NotFound, ParameterException
from lin.interface import InfoCrud as Base
from sqlalchemy import Column, String, Integer, orm, ForeignKey,Float
from sqlalchemy import or_
from sqlalchemy.orm import relationship, backref
from sqlalchemy.dialects.mysql import LONGTEXT, DATE

from app.libs.error_code import EateryNotFound,NotFound


class Eatery(Base):

    __tablename__ = 'eatery'

    id = Column(Integer, primary_key=True, autoincrement=True)
    u_id = Column(Integer, nullable=True)
    link = Column(LONGTEXT,nullable=True)
    cuisine = Column(String(50),nullable=False)
    rating = Column(Float,nullable=False)
    name = Column(String(50), nullable=False)
    address = Column(LONGTEXT,nullable=False)
    coordinate_lng = Column(Float,nullable=False)
    coordinate_lat = Column(Float,nullable=False)
    phone = Column(String(20), nullable=False)
    from_info = Column(LONGTEXT,nullable=True)
    description = Column(LONGTEXT,nullable=True)


    @classmethod
    def get_all_cuisine(cls):
        cuisines = Eatery.query.with_entities(Eatery.cuisine).distinct().all()
        _cuisines = []
        for cuisine in cuisines:
          if ',' in cuisine[0]:
            _cuisines.extend(cuisine[0].split(','))
          else:
            _cuisines.append(cuisine[0])
        return list(set(_cuisines))

    @classmethod
    def get_detail(cls, eid):
        eatery = cls.query.filter_by(id=eid, delete_time=None).first()
        if eatery is None:
            raise NotFound(msg='Not found')
        return eatery

    @classmethod
    def get_all_uid(cls, uid):
        eateries = cls.query.filter_by(u_id=uid, delete_time=None).all()
        return eateries

    @classmethod
    def get_all_registered(cls):
        eateries = cls.query.filter_by(u_id=None, delete_time=None).all()
        return eateries

    @classmethod
    def get_all(cls):
        eateries = cls.query.filter_by(delete_time=None).all()
        if not eateries:
            raise NotFound(msg='Not found')
        return eateries

    @classmethod
    def update_uid(cls,eid,uid):
        entery = Eatery.query.filter_by(id=eid, delete_time=None).first()
        if entery is None:
            raise NotFound(msg='No found')

        entery.update(
            id=eid,
            u_id = uid,
            commit=True
        )
        return True

    @classmethod
    def search_by_cuisine(cls, eid):
        eatery = Eatery.query.filter_by(id=eid, delete_time=None).first()
        _cuisine = []
        if ',' in eatery.cuisine:
          _cuisine = eatery.cuisine.split(',')
        else:
          _cuisine = eatery.cuisine

        if isinstance(_cuisine,list):
          eateries = cls.query.filter(
                or_(Eatery.cuisine.like('%' + _cuisine[0] + '%'),
                  Eatery.cuisine.like('%' + _cuisine[1] + '%')),
                  Eatery.delete_time == None,Eatery.id != eid ).all()
        else:
          eateries = cls.query.filter(
               Eatery.cuisine.like('%' + _cuisine + '%'),
               Eatery.delete_time == None,Eatery.id != eid ).all()
        return eateries

    @classmethod
    def search_by_cuisine_all(cls,cuisine):
        eateries = cls.query.filter(
               Eatery.cuisine.like('%' + cuisine.strip() + '%'),
               Eatery.delete_time == None).all()
        return eateries

    @classmethod
    def search_by_keywords(cls, q):
        eateries = cls.query.filter(Eatery.name.like('%' + q.strip() + '%'), Eatery.delete_time == None).all()
        return eateries

    @classmethod
    def get_simple(cls):
        eateries = cls.query.filter(Eatery.delete_time == None,Eatery.u_id == None).limit(10)
        return eateries

    # @classmethod
    # def new_book(cls, form):
    #     # location need process
    #     entery = cls.query.filter_by(location=form.location.data, delete_time=None).first()
    #     if entery is not None:
    #         raise ParameterException(msg='Some location has been registered by other user')

    #     Entery.create(
    #         u_id = form.u_id.data,
    #         name=form.name.data,
    #         location=form.location.data,
    #         phone=form.phone.data,
    #         image=form.image.data,
    #         commit=True
    #     )
    #     return True

    # @classmethod
    # def edit_book(cls, eid, form):
    #     entery = Entery.query.filter_by(id=eid, delete_time=None).first()
    #     if entery is None:
    #         raise NotFound(msg='No found')

    #     entery.update(
    #         id=eid,
    #         name=form.name.data,
    #         location=form.location.data,
    #         phone=form.phone.data,
    #         image=form.image.data,
    #         commit=True
    #     )
    #     return True

    # @classmethod
    # def remove_entry(cls, eid):
    #     entery = Entery.cls.query.filter_by(id=eid, delete_time=None).first()
    #     if entery is None:
    #         raise NotFound(msg='No found')
    #     # 删除图书，软删除
    #     entery.delete(commit=True)
    #     return True
