"""
    :copyright: © 2019 by the Lin team.
    :license: MIT, see LICENSE for more details.
"""
from lin.exception import NotFound, ParameterException
from lin.interface import InfoCrud as Base
from sqlalchemy import Column, String, Integer, orm, ForeignKey,Float
from sqlalchemy.orm import relationship, backref
from sqlalchemy.dialects.mysql import LONGTEXT, DATE

from app.libs.error_code import EateryNotFound


class Review(Base):

    __tablename__ = 'review'

    id = Column(Integer, primary_key=True, autoincrement=True)
    e_id = Column(Integer, ForeignKey('eatery.id'))
    reviewer_name = Column(LONGTEXT,nullable=False)
    content = Column(LONGTEXT,nullable=False)
    rating = Column(Float,nullable=True)
    comments_num = Column(Integer, nullable=True)
    helpful_num = Column(Integer, nullable=True)
    arriving_time = Column(String(50), nullable=True)
    review_time = Column(String(50), nullable=True)
    reported = Column(Integer, server_default='0')

    @classmethod
    def get_detail(cls, eid):
        review = cls.query.filter_by(id=eid, delete_time=None).first()
        if review is None:
            raise NotFound(msg='Not found')
        return review

    @classmethod
    def get_detail_nonreported(cls, eid):
        reviews = cls.query.filter_by(e_id=eid, delete_time=None,reported=0).all()
        return reviews

    @classmethod
    def get_all(cls):
        reviews = cls.query.filter_by(delete_time=None).all()
        if not reviews:
            raise NotFound(msg='Not found')
        return reviews

    @classmethod
    def search_by_keywords(cls, q):
        reviews = cls.query.filter(Review.name.like('%' + q + '%'), Review.delete_time == None).all()
        if not reviews:
            raise EateryNotFound()
        return reviews

    # @classmethod
    # def new_book(cls, form):
    #     # location need process
    #     entery = cls.query.filter_by(location=form.location.data, delete_time=None).first()
    #     if entery is not None:
    #         raise ParameterException(msg='Some location has been registered by other user')

    #     Entery.create(
    #         u_id = form.u_id.data,
    #         name=form.name.data,
    #         location=form.location.data,
    #         phone=form.phone.data,
    #         image=form.image.data,
    #         commit=True
    #     )
    #     return True

    # @classmethod
    # def edit_book(cls, eid, form):
    #     entery = Entery.query.filter_by(id=eid, delete_time=None).first()
    #     if entery is None:
    #         raise NotFound(msg='No found')

    #     entery.update(
    #         id=eid,
    #         name=form.name.data,
    #         location=form.location.data,
    #         phone=form.phone.data,
    #         image=form.image.data,
    #         commit=True
    #     )
    #     return True

    # @classmethod
    # def remove_entry(cls, eid):
    #     entery = Entery.cls.query.filter_by(id=eid, delete_time=None).first()
    #     if entery is None:
    #         raise NotFound(msg='No found')
    #     # 删除图书，软删除
    #     entery.delete(commit=True)
    #     return True
