"""
    :copyright: © 2019 by the Lin team.
    :license: MIT, see LICENSE for more details.
"""
from lin.exception import NotFound, ParameterException
from lin.interface import InfoCrud as Base
from sqlalchemy import Column, String, Integer, orm, ForeignKey
from sqlalchemy.orm import relationship, backref
from sqlalchemy.dialects.mysql import LONGTEXT, DATE

from app.libs.error_code import ReportNotFound

from app.libs.utils import date_to_timestamp

from lin import db


class ReportItemReview(Base):

    __tablename__ = 'report_item_review'

    id = Column(Integer, primary_key=True, autoincrement=True)
    ri_id = Column(Integer, ForeignKey('report_item.id'))
    sentiment_type = Column(String(10), nullable=False)
    content = Column(LONGTEXT, nullable=False)

    @classmethod
    def get_report_review_by_riid(cls,sentiment_type, riid):
        report_item_review = ReportItemReview.query.filter_by(ri_id=riid,sentiment_type=sentiment_type, delete_time=None).all()
        return report_item_review
