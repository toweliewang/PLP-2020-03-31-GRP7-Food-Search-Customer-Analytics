"""
    :copyright: © 2019 by the Lin team.
    :license: MIT, see LICENSE for more details.
"""
from lin.exception import NotFound, ParameterException
from lin.interface import InfoCrud as Base
from sqlalchemy import Column, String, Integer, orm, ForeignKey
from sqlalchemy.orm import relationship, backref
from sqlalchemy.dialects.mysql import LONGTEXT, DATE

from app.libs.error_code import ReportNotFound

from app.libs.utils import date_to_timestamp

from app.models.review import Review
from app.models.report_item import ReportItem
from app.models.report_item_review import ReportItemReview

import pandas as pd

from app.libs.utils import month2num,num2month
from app.models.eatery import Eatery

from lin import db


class Report(Base):

    __tablename__ = 'report'

    id = Column(Integer, primary_key=True, autoincrement=True)
    e_id = Column(Integer, ForeignKey('eatery.id'))
    report_range = Column(String(200), nullable=False)
    overall_score = Column(Integer, nullable=True)
    overall_summary = Column(LONGTEXT, nullable=True)
    food_summary = Column(LONGTEXT, nullable=True)

    @classmethod
    def get_all_report(cls, eid):
        reports = Report.query.filter_by(e_id=eid, delete_time=None).order_by(Report._create_time.desc()).all()
        return reports

    @classmethod
    def clear_report(cls,eid):
        reports = Report.query.filter_by(e_id=eid, delete_time=None).order_by(Report._create_time.desc()).all()
        for _report in reports:
            _items = ReportItem.query.filter_by(r_id=_report.id, delete_time=None).all()
            for i in _items:
                _reviews = ReportItemReview.query.filter_by(ri_id=i.id, delete_time=None).all()
                for _review in _reviews:
                    _review.hard_delete()
                    db.session.flush()
                i.hard_delete()
                db.session.flush()
            _report.hard_delete()
            db.session.flush()


    @classmethod
    def get_all_other_repot(cls,eid,rid):
        reports = Report.query.filter(Report.e_id==eid,Report.id != rid, delete_time=None).order_by(Report._create_time.desc()).all()
        return reports

    @classmethod
    def get_latest_report(cls,eid):
        report = Report.query.filter_by(e_id=eid,delete_time=None).order_by(Report._create_time.desc()).first()
        return report


    @classmethod
    def generate(cls,eid):
        from app.sa.sentiment_utils import Process
        eatery = Eatery.get(id=eid)
        p = Process()
        reviews = Review.get_detail_nonreported(eid=eid)
        _df = pd.DataFrame(columns=['res_id', 'review','arriving_month','arriving_year'])
        for review in reviews:
            _df.loc[len(_df)] = [review.e_id,review.content,month2num(review.arriving_time.split('-')[0].strip()),int(review.arriving_time.split('-')[1].strip())]

        ## group by arriving time monthly
        df_gb = _df.groupby(['arriving_year','arriving_month'])

        month_list = []
        year_list = []

        count = 0
        _time_temp = []
        _df_temp = pd.DataFrame(columns=['res_id', 'review','arriving_month','arriving_year'])
        for (index1,index2), data in df_gb:
                count = count + data.size
                if count <= 150:
                    print(data.size)
                    _time_temp.append(str(index1) + '_' + num2month(index2))
                    if _df_temp.empty:
                        _df_temp = pd.concat((_df_temp,data),axis=0)
                    else:
                        _df_temp = data
                else:
                    try:
                      print("=" * 100)
                      _time_temp.append(str(index1) + '_' + num2month(index2))
                      print(_time_temp)
                      print(count)
                      _df_temp = pd.concat((_df_temp,data),axis=0)
                      _df_temp.to_csv('error.csv',index=False)
                      overall_score,overall_summary,food_report,service_report,price_report,environment_report \
                        = p.sa_process(_df_temp[['res_id','review']],(eatery.name).strip())

                      print(overall_score)
                      print(overall_summary)
                      print(food_report)
                      print(service_report)
                      print(price_report)
                      print(environment_report)

                      with db.auto_commit():
                        report = Report()
                        report.e_id = eatery.id
                        report.overall_score = overall_score
                        report.report_range = ','.join(_time_temp)
                        report.overall_summary = overall_summary
                        report.food_summary = food_report['food_summary']
                        db.session.add(report)
                        db.session.flush()

                        # food_report
                        for _food_re in food_report['reports']:
                          report_item_food = ReportItem()
                          report_item_food.r_id = report.id
                          report_item_food.item_type = 'food'
                          report_item_food.entity = _food_re['entity']
                          report_item_food.score = _food_re['score']
                          report_item_food.positive = _food_re['positive_num']
                          report_item_food.negative = _food_re['negative_num']
                          db.session.add(report_item_food)
                          db.session.flush()

                          if _food_re['positive_reviews']:
                              for i_r in _food_re['positive_reviews']:
                                  food_review = ReportItemReview()
                                  food_review.ri_id = report_item_food.id
                                  food_review.sentiment_type = 'positive'
                                  food_review.content = i_r
                                  db.session.add(food_review)
                          if _food_re['negative_reviews']:
                              for i_r in _food_re['negative_reviews']:
                                  food_review = ReportItemReview()
                                  food_review.ri_id = report_item_food.id
                                  food_review.sentiment_type = 'negative'
                                  food_review.content = i_r
                                  db.session.add(food_review)

                        # service_report
                        report_item_service = ReportItem()
                        report_item_service.r_id = report.id
                        report_item_service.item_type = 'service'
                        report_item_service.score = service_report['score']
                        report_item_service.positive = service_report['positive_num']
                        report_item_service.negative = service_report['negative_num']
                        db.session.add(report_item_service)
                        db.session.flush()

                        if service_report['positive_reviews']:
                            for i_r in service_report['positive_reviews']:
                                service_review = ReportItemReview()
                                service_review.ri_id = report_item_service.id
                                service_review.sentiment_type = 'positive'
                                service_review.content = i_r
                                db.session.add(service_review)
                        if service_report['negative_reviews']:
                            for i_r in service_report['negative_reviews']:
                                service_review = ReportItemReview()
                                service_review.ri_id = report_item_service.id
                                service_review.sentiment_type = 'negative'
                                service_review.content = i_r
                                db.session.add(service_review)
                                

                        # price_report
                        report_item_price = ReportItem()
                        report_item_price.r_id = report.id
                        report_item_price.item_type = 'price'
                        report_item_price.score = price_report['score']
                        report_item_price.positive = price_report['positive_num']
                        report_item_price.negative = price_report['negative_num']
                        report_item_price.neutral = price_report['valuation_num']
                        db.session.add(report_item_price)
                        db.session.flush()

                        if price_report['positive_reviews']:
                            for i_r in price_report['positive_reviews']:
                                price_review = ReportItemReview()
                                price_review.ri_id = report_item_price.id
                                price_review.sentiment_type = 'positive'
                                price_review.content = i_r
                                db.session.add(price_review)
                        if price_report['negative_reviews']:
                            for i_r in price_report['negative_reviews']:
                                price_review = ReportItemReview()
                                price_review.ri_id = report_item_price.id
                                price_review.sentiment_type = 'negative'
                                price_review.content = i_r
                                db.session.add(price_review)
                        if price_report['valuation_reviews']:
                            for i_r in price_report['valuation_reviews']:
                                price_review = ReportItemReview()
                                price_review.ri_id = report_item_price.id
                                price_review.sentiment_type = 'neutral'
                                price_review.content = i_r
                                db.session.add(price_review)

                        # environment_report
                        report_item_env = ReportItem()
                        report_item_env.r_id = report.id
                        report_item_env.item_type = 'environment'
                        report_item_env.score = environment_report['score']
                        report_item_env.positive = environment_report['positive_num']
                        report_item_env.negative = environment_report['negative_num']
                        db.session.add(report_item_env)
                        db.session.flush()

                        if environment_report['positive_reviews']:
                            for i_r in environment_report['positive_reviews']:
                                env_review = ReportItemReview()
                                env_review.ri_id = report_item_env.id
                                env_review.sentiment_type = 'positive'
                                env_review.content = i_r
                                db.session.add(env_review)
                        if environment_report['negative_reviews']:
                            for i_r in environment_report['negative_reviews']:
                                env_review = ReportItemReview()
                                env_review.ri_id = report_item_env.id
                                env_review.sentiment_type = 'negative'
                                env_review.content = i_r
                                db.session.add(env_review)

                      count = 0
                      _time_temp = []
                      _df_temp = pd.DataFrame(columns=['res_id', 'review','arriving_month','arriving_year'])
                    except IndexError as e:
                      print(e)
                      continue
        del p
