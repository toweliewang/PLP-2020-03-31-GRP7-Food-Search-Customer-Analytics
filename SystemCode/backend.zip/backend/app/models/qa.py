"""
    :copyright: © 2019 by the Lin team.
    :license: MIT, see LICENSE for more details.
"""
from lin.exception import NotFound, ParameterException
from lin.interface import InfoCrud as Base
from sqlalchemy import Column, String, Integer, orm, ForeignKey
from sqlalchemy.orm import relationship, backref
from sqlalchemy.dialects.mysql import LONGTEXT, DATE

from app.libs.error_code import ReportNotFound

from app.libs.utils import date_to_timestamp

from lin import db


class QA(Base):

    __tablename__ = 'qa'

    id = Column(Integer, primary_key=True, autoincrement=True)
    question = Column(LONGTEXT, nullable=False)
    answer = Column(LONGTEXT, nullable=False)
    satisfactory = Column(Integer, nullable=False,server_default='0')

    @classmethod
    def add_qa(cls,question, answer,satisfactory):
        with db.auto_commit():
            qa = QA()
            qa.question = question
            qa.answer = answer
            qa.satisfactory = satisfactory
            db.session.add(qa)
        return True
