"""
    :copyright: © 2019 by the Lin team.
    :license: MIT, see LICENSE for more details.
"""
from lin.exception import NotFound, ParameterException
from lin.interface import InfoCrud as Base
from sqlalchemy import Column, String, Integer, orm, ForeignKey
from sqlalchemy.orm import relationship, backref
from sqlalchemy.dialects.mysql import LONGTEXT, DATE

from app.libs.error_code import ReportNotFound

from app.libs.utils import date_to_timestamp

from lin import db


class Entity(Base):

    __tablename__ = 'entity'

    id = Column(Integer, primary_key=True, autoincrement=True)
    entity_type  = Column(String(16),nullable=False)
    content = Column(LONGTEXT,nullable=False)

    @classmethod
    def get_for_entites_bytype(cls, entity_type):
        entities = Entity.query.filter_by(entity_type=entity_type,delete_time=None).all()
        content = [e.content for e in entities]
        return content

    @classmethod
    def add_entity(cls, entity_type,content):
        with db.auto_commit():
            entity = Entity()
            entity.entity_type = entity_type
            entity.content = content
            db.session.add(entity)
        return True
