"""
    :copyright: © 2019 by the Lin team.
    :license: MIT, see LICENSE for more details.
"""
from lin.exception import NotFound, ParameterException
from lin.interface import InfoCrud as Base
from sqlalchemy import Column, String, Integer, orm, ForeignKey
from sqlalchemy.orm import relationship, backref
from sqlalchemy.dialects.mysql import LONGTEXT, DATE


class ReportItem(Base):

    __tablename__ = 'report_item'

    id = Column(Integer, primary_key=True, autoincrement=True)
    r_id = Column(Integer, ForeignKey('report.id'))
    item_type = Column(String(20),nullable=False)
    entity = Column(String(50),nullable=False)
    positive = Column(Integer,nullable=False)
    positive_score = Column(Integer,nullable=False)
    negative = Column(Integer,nullable=False)
    negative_score = Column(Integer,nullable=False)
    neutral = Column(Integer,nullable=False)
    neutral_score = Column(Integer,nullable=False)

    @classmethod
    def get_for_report_singletype(cls, item_type,rid):
        report_items = ReportItem.query.filter_by(r_id=rid,item_type=item_type, delete_time=None).all()
        if report_items is None:
            raise NotFound(msg='Not found')
        return report_items

    @classmethod
    def get_for_report_types(cls,item_types,rid):
        report_items = {}
        for item_type in report_items:
          report_items[item_type] = cls.get_for_report_singletype(item_type,rid)
        if not report_items:
            raise NotFound(msg='Not found')
        return report_items

    @classmethod
    def new_report_item(cls, form):

        ReportItem.create(
            r_d = form.r_id.data,
            item_type=form.name.data,
            entity=form.location.data,
            positive = form.location.data,
            positive_score = form.positive_score.data,
            negative = form.negative.data,
            negative_score = form.negative_score.data,
            neutral = form.neutral.data,
            neutral_score = form.neutral_score.data,
            commit=True
        )

        return True