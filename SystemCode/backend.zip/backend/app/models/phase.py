"""
    :copyright: © 2019 by the Lin team.
    :license: MIT, see LICENSE for more details.
"""
from lin.exception import NotFound, ParameterException
from lin.interface import InfoCrud as Base
from sqlalchemy import Column, String, Integer, orm, ForeignKey
from sqlalchemy.orm import relationship, backref
from sqlalchemy.dialects.mysql import LONGTEXT, DATE

from app.libs.error_code import ReportNotFound

from app.libs.utils import date_to_timestamp

from lin import db


class Phase(Base):

    __tablename__ = 'phase'

    id = Column(Integer, primary_key=True, autoincrement=True)
    phase_type  = Column(String(16),nullable=False)
    content = Column(LONGTEXT,nullable=False)

    @classmethod
    def get_for_phase_bytype(cls, phase_type):
        phases = Phase.query.filter_by(phase_type=phase_type,delete_time=None).all()
        content = [p.content for p in phases]
        return content

    @classmethod
    def add_phase(cls, phase_type,content):
        with db.auto_commit():
            phase = Phase()
            phase.phase_type = phase_type
            phase.content = content
            db.session.add(phase)
        return True
