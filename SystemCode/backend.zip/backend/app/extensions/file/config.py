# 文件相关配置
FILE = {
    "STORE_DIR": 'app/assets',
    "SINGLE_LIMIT": 1024 * 1024 * 2,
    "TOTAL_LIMIT": 1024 * 1024 * 20,
    "NUMS": 10,
    "INCLUDE": set([]),
    "EXCLUDE": set([])
}
