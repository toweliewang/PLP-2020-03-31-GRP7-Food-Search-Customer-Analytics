def to_category_price(df, display):
  
  index = list()
  underval_idx = list()
  overval_idx = list()
  price_tag = ['price','value','money','dollar','worth', 'cheap', 'expensive', 'costly']

  for idx, val in enumerate(df['review']):
    for token in nlp(val,disable=['sentencizer']):
        if token.pos_ in ['NOUN'] and token.text in price_tag:
            index.append(idx)
        if token.pos_ in ['ADJ'] and token.text in price_tag:
            index.append(idx)
        if token.pos_ in ['SYM'] and token.text =='$':
            index.append(idx)
        if token.pos_ in ['ADJ'] and token.text in ['cheap']:
            underval_idx.append(idx)
        if token.pos_ in ['ADJ'] and token.text in ['expensive','costly']:
            overval_idx.append(idx)

  # get dataframe
  price_df = df.iloc[index].drop_duplicates()
  overval_df = df.iloc[overval_idx].drop_duplicates()
  underval_df = df.iloc[underval_idx].drop_duplicates()
  # get num of review
  val_num = len(overval_df)+len(underval_df)
  pos_num = sum(price_df['polarity'])
  neg_num = len(price_df['polarity']) - pos_num
  # get score
  score = (pos_num/(pos_num + neg_num))*10
  # get text of review
  pos_review = price_df.sort_values(by='score')[-1:-display-1:-1].reset_index().review
  neg_review = price_df.sort_values(by='score')[0:display].reset_index().review
  overval_review = overval_df.sort_values(by='score')[0:display-2].reset_index().review
  underval_review = underval_df.sort_values(by='score')[-1:-display+2:-1].reset_index().review  # maybe few 
  valuation = overval_review.append(underval_review, ignore_index=True)
  # get dataframe
  review = pd.DataFrame({'positive': pos_review,
                         'negative': neg_review,
                         'valuation': valuation})

  barchart = pd.DataFrame({'name':['positive','negative','valuation'],
                           'price_score':[score,score,score],
                           'num_review':[pos_num, neg_num, val_num]})

  return barchart, review




# main：该餐馆的整个数据 dataframe
# display：展示每个方面的前n条评论
display = 5
barchart, review = to_category_price(main, display)