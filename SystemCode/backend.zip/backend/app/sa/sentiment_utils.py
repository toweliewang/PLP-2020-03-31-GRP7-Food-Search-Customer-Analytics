import plac
import random
import pathlib
import cytoolz
import numpy
import pandas as pd 
import keras
from keras.models import Sequential, model_from_json
from keras.layers import LSTM, Dense, Embedding, Bidirectional
from keras.layers import TimeDistributed
from keras.optimizers import Adam
from spacy.compat import pickle
from spacy.matcher import PhraseMatcher
import spacy
import time
import threading

# from app.models.eatery import Eatery
# from app.models.review import Review

from app.libs.models import Singleton

class SentimentProcessor(object):

    def __init__(self):
        self.food_tag = ['food','menu','dishes','taste','course','wine','dish',
                    'dessert','beef','cake','drinks','seafood','tea','steak','meat',
                    'salad','desserts','chicken','prok','coffee','ingredients','pizza',
                    'pasta','beer','soup','rice','bread']
        self.ser_tag = ['service','staff','experience','attitude','table','team',
           'munute','munutes', 'chef','waiter','manager','friendly',
           'attentive', 'warm', 'helpful', 'professional', 'polite', 
           'busy','courteous']  
        self.env_tag = ['environemnt','ambience','atmosphere','decoration','dark','dim',
           'luxury','music','ambience','setting','ambient','surroundings',
           'milieu','mood','aura','surround','room','clean','private']
        self.price_tag = ['price','prices','value','money','dollar','worth', 'expensive', 'cheap', 
             'costly', 'reasonable','pricey','affordable']

        self.prepare()

    def prepare(self):
        # # for preprocess
        # nlp = spacy.load('en_core_web_sm',disable=['parser','ner'])
        # nlp.add_pipe(nlp.create_pipe("sentencizer"))
        # # for sentiment
        # nlp_sentiment = spacy.load(path_vectors)
        # nlp_sentiment.add_pipe(nlp.create_pipe("sentencizer"))
        # nlp_sentiment.add_pipe(SentimentAnalyser.load(nlp_sentiment, path_model, 100))

        models = Singleton.instance()
        # check pipeline
        self.nlp = models.nlp
        self.nlp_sentiment = models.nlp_sentiment
        print("prepare done")

    def docs2sent(self,docs):
        # pipeline can process with batches ,will be faster than pipeline single element 
        allsents =list()
        for docsents in list(self.nlp.pipe(list(docs['review']))):
            for doc in docsents.sents:
                allsents.append(doc.text)
        # print('docs2sent:')
        # print(len(docs))
        # print(len(allsents))
        # print(type(allsents[0])) 
        # print(allsents[0])

        return allsents

    def num_polarity(self,df):
        num_pos = sum(df['polarity'])
        num_neg = len(df['polarity']) - num_pos
        # print('number of positive reviews: ' + str(num_pos))
        # print('number of negative reviews: ' + str(num_neg))

        return num_pos, num_neg

    def sent2score(self,df):
        allsents = self.docs2sent(df)
        review =list()
        score = list()
        for doc in self.nlp_sentiment.pipe(allsents):
            review.append(doc.text)
            score.append(doc.sentiment)
        main = pd.DataFrame({'review':review,'score':score})
        main['polarity'] = main['score'].apply(lambda x: 1 if x >= 0.5 else 0)
        main['sentiment'] = main['score'].apply(lambda x: 'positive' if x >= 0.5 else 'negative')
        main_pos, main_neg = self.num_polarity(main)
        # main.to_csv('main.temp.csv')

        return main, main_pos, main_neg


    def get_food(self,main, res_name):

        # load data
        res_name = res_name.strip()
        res_food = pd.read_excel('app/sa/RelData.xlsx',sheet_name='res_food')
        # get food list 
        food_graph = res_food[res_food['name1']==res_name]['name2'].tolist()
        from spacy.matcher import PhraseMatcher
        nlp_food = spacy.load('en_core_web_sm')
        matcher = PhraseMatcher(nlp_food.vocab, attr="LOWER")
        patterns = [nlp_food.make_doc(name) for name in food_graph]
        matcher.add("Names", None, *patterns)
        index = list()
        food_entity = list()
        for idx, val in enumerate(main['review']):
          doc = nlp_food(val)
          for match_id, start, end in matcher(doc):
              index.append(idx)
              food_entity.append(doc[start:end])
              df = pd.DataFrame({'index':index,'food_entity':food_entity})
        # get top 4 food
        df['food_entity'] = df['food_entity'].astype(str) 

        # try four food 
        food_name = df['food_entity'].value_counts()[:4].index.tolist()
        print(food_name)

        if len(food_name)==4:
          
          print(df['food_entity'].value_counts())
          index1 = df[df['food_entity']==food_name[0]]['index']
          index2 = df[df['food_entity']==food_name[1]]['index']
          index3 = df[df['food_entity']==food_name[2]]['index']
          index4 = df[df['food_entity']==food_name[3]]['index']
          df1 = main.iloc[index1,:].drop_duplicates()
          df2 = main.iloc[index2,:].drop_duplicates()
          df3 = main.iloc[index3,:].drop_duplicates()
          df4 = main.iloc[index4,:].drop_duplicates()
          pos1 = sum(df1['polarity'])
          neg1 = len(df1['polarity']) - pos1
          pos2 = sum(df2['polarity'])
          neg2 = len(df2['polarity']) - pos2
          pos3 = sum(df3['polarity'])
          neg3 = len(df3['polarity']) - pos3
          pos4 = sum(df4['polarity'])
          neg4 = len(df4['polarity']) - pos4
          score1 = round((pos1/(pos1+neg1))*10,2)
          score2 = round((pos2/(pos2+neg2))*10,2)
          score3 = round((pos3/(pos3+neg3))*10,2)
          score4 = round((pos4/(pos4+neg4))*10,2)
          df_foodsummary = pd.DataFrame({'name':[food_name[0],
                                                food_name[1],
                                                food_name[2],
                                                food_name[3]],
                                'score':[score1,score2,score3,score4],
                                'pos':[pos1,pos2,pos3,pos4],
                                'neg':[neg1,neg2,neg3,neg4]})

          food1_top_pos, food1_top_neg = self.get_top(df1)
          food1_report = {
                'entity':food_name[0],
                'score':score1,
                'positive_num':pos1,
                'negative_num':neg1,
                'positive_reviews':food1_top_pos[:10].tolist(),
                'negative_reviews':food1_top_neg[:10].tolist()
          }

          food2_top_pos, food2_top_neg = self.get_top(df2)
          food2_report = {
                'entity':food_name[1],
                'score':score2,
                'positive_num':pos2,
                'negative_num':neg2,
                'positive_reviews':food2_top_pos[:10].tolist(),
                'negative_reviews':food2_top_neg[:10].tolist()
          }

          food3_top_pos, food3_top_neg = self.get_top(df3)
          food3_report = {
                'entity':food_name[2],
                'score':score3,
                'positive_num':pos3,
                'negative_num':neg3,
                'positive_reviews':food3_top_pos[:10].tolist(),
                'negative_reviews':food3_top_neg[:10].tolist()
          }

          food4_top_pos, food4_top_neg = self.get_top(df4)
          food4_report = {
                'entity':food_name[3],
                'score':score4,
                'positive_num':pos4,
                'negative_num':neg4,
                'positive_reviews':food4_top_pos[:10].tolist(),
                'negative_reviews':food4_top_neg[:10].tolist()
          }

          foods_report = [food1_report,
                          food2_report,
                          food3_report,
                          food4_report]

          return foods_report, df_foodsummary

        elif  len(food_name)==3:

            index1 = df[df['food_entity']==food_name[0]]['index']
            index2 = df[df['food_entity']==food_name[1]]['index']
            index3 = df[df['food_entity']==food_name[2]]['index']
            df1 = main.iloc[index1,:].drop_duplicates()
            df2 = main.iloc[index2,:].drop_duplicates()
            df3 = main.iloc[index3,:].drop_duplicates()
            pos1 = sum(df1['polarity'])
            neg1 = len(df1['polarity']) - pos1
            pos2 = sum(df2['polarity'])
            neg2 = len(df2['polarity']) - pos2
            pos3 = sum(df3['polarity'])
            neg3 = len(df3['polarity']) - pos3
            score1 = round((pos1/(pos1+neg1))*10,2)
            score2 = round((pos2/(pos2+neg2))*10,2)
            score3 = round((pos3/(pos3+neg3))*10,2)

            df_foodsummary = pd.DataFrame({'name':[food_name[0],
                                                  food_name[1],
                                                  food_name[2]],
                                  'score':[score1,score2,score3],
                                  'pos':[pos1,pos2,pos3],
                                  'neg':[neg1,neg2,neg3]})
            
            food1_top_pos, food1_top_neg = self.get_top(df1)
            food1_report = {
                  'entity':food_name[0],
                  'score':score1,
                  'positive_num':pos1,
                  'negative_num':neg1,
                  'positive_reviews':food1_top_pos[:10].tolist(),
                  'negative_reviews':food1_top_neg[:10].tolist()
            }

            food2_top_pos, food2_top_neg = self.get_top(df2)
            food2_report = {
                  'entity':food_name[1],
                  'score':score2,
                  'positive_num':pos2,
                  'negative_num':neg2,
                  'positive_reviews':food2_top_pos[:10].tolist(),
                  'negative_reviews':food2_top_neg[:10].tolist()
            }

            food3_top_pos, food3_top_neg = self.get_top(df3)
            food3_report = {
                  'entity':food_name[2],
                  'score':score3,
                  'positive_num':pos3,
                  'negative_num':neg3,
                  'positive_reviews':food3_top_pos[:10].tolist(),
                  'negative_reviews':food3_top_neg[:10].tolist()
            }


            foods_report = [food1_report,
                            food2_report,
                            food3_report]

            return foods_report, df_foodsummary

        elif len(food_name)==2:

            index1 = df[df['food_entity']==food_name[0]]['index']
            index2 = df[df['food_entity']==food_name[1]]['index']
            df1 = main.iloc[index1,:].drop_duplicates()
            df2 = main.iloc[index2,:].drop_duplicates()
            pos1 = sum(df1['polarity'])
            neg1 = len(df1['polarity']) - pos1
            pos2 = sum(df2['polarity'])
            neg2 = len(df2['polarity']) - pos2
            score1 = round((pos1/(pos1+neg1))*10,2)
            score2 = round((pos2/(pos2+neg2))*10,2)
            df_foodsummary = pd.DataFrame({'name':[food_name[0],
                                                    food_name[1]],
                                  'score':[score1,score2],
                                  'pos':[pos1,pos2],
                                  'neg':[neg1,neg2]})
            
            food1_top_pos, food1_top_neg = self.get_top(df1)
            food1_report = {
                  'entity':food_name[0],
                  'score':score1,
                  'positive_num':pos1,
                  'negative_num':neg1,
                  'positive_reviews':food1_top_pos[:10].tolist(),
                  'negative_reviews':food1_top_neg[:10].tolist()
            }

            food2_top_pos, food2_top_neg = self.get_top(df2)
            food2_report = {
                  'entity':food_name[1],
                  'score':score2,
                  'positive_num':pos2,
                  'negative_num':neg2,
                  'positive_reviews':food2_top_pos[:10].tolist(),
                  'negative_reviews':food2_top_neg[:10].tolist()
            }

            foods_report = [food1_report,
                            food2_report]

            return foods_report, df_foodsummary

        else:
            print('find only one food entity')
            raise(IndexError)

    # food summary

    def food_summary(self,df):
      
        df_bad = df[df['score'] ==df['score'].min()]
        df_good = df[df['score'] ==df['score'].max()]
        bad_name = df_bad['name'].iloc[0]
        bad_num = df_bad['neg'].iloc[0]
        good_name = df_good['name'].iloc[0]
        good_num = df_good['pos'].iloc[0]
        food_summary = f'<b>{good_num}</b> customers were satisfied with your <b>{good_name}</b>, \nbut there were still <b>{bad_num}</b> negative reviews on the <b>{bad_name}</b>.'

        return food_summary
    
    def category_summary(self,df):

        df_bad = df[df['score'] ==df['score'].min()]
        df_good = df[df['score'] ==df['score'].max()]
        bad_name = df_bad['name'].iloc[0]
        bad_num = df_bad['neg'].iloc[0]
        good_name = df_good['name'].iloc[0]
        good_num = df_good['pos'].iloc[0]
        category_summary =f'<b>{good_num}</b> customers loved your <b>{good_name}</b>, \nhowever, among the food your restaurant provided, you might need to find out the reason why <b>{bad_name}</b> has received <b>{bad_num}</b> negative reviews.'

        return category_summary

    def to_category_price(self,df, display):
        try:
            index = list()
            underval_idx = list()
            overval_idx = list()
            price_tag = ['price','value','money','dollar','worth', 'cheap', 'expensive', 'costly']

            for idx, val in enumerate(df['review']):
              for token in self.nlp(val,disable=['sentencizer']):
                  if token.pos_ in ['NOUN'] and token.text in price_tag:
                      index.append(idx)
                  if token.pos_ in ['ADJ'] and token.text in price_tag:
                      index.append(idx)
                  if token.pos_ in ['SYM'] and token.text =='$':
                      index.append(idx)
                  if token.pos_ in ['ADJ'] and token.text in ['cheap']:
                      underval_idx.append(idx)
                  if token.pos_ in ['ADJ'] and token.text in ['expensive','costly']:
                      overval_idx.append(idx)

            # get dataframe
            price_df = df.iloc[index].drop_duplicates()
            overval_df = df.iloc[overval_idx].drop_duplicates()
            underval_df = df.iloc[underval_idx].drop_duplicates()
            # get num of review
            val_num = len(overval_df)+len(underval_df)
            pos_num = sum(price_df['polarity'])
            neg_num = len(price_df['polarity']) - pos_num

            print(val_num)
            print(pos_num)
            print(neg_num)
            # get score
            score = (pos_num/(pos_num + neg_num))*10
            # get text of review
            pos_review = price_df[price_df['polarity']==1].sort_values(by='score')[-1:-display-1:-1].reset_index().review
            neg_review = price_df[price_df['polarity']==0].sort_values(by='score')[0:display].reset_index().review
            overval_review = overval_df.sort_values(by='score')[0:display-2].reset_index().review
            underval_review = underval_df.sort_values(by='score')[-1:-display+2:-1].reset_index().review  # maybe few 
            valuation = overval_review.append(underval_review, ignore_index=True)

            return score,pos_num,neg_num,val_num,pos_review,neg_review,valuation
        except ZeroDivisionError as e:
            df.to_csv("error_price.csv",index=False)

    def to_category(self,df, category_name):
        index = list()
        for idx, val in enumerate(df['review']):
            for token in self.nlp(val,disable=['sentencizer']):
                if token.pos_ in ['NOUN'] and token.text in category_name:
                    index.append(idx)
                if token.pos_ in ['NOUN'] and token.text in category_name:
                    index.append(idx)
                if category_name[0] !='food' and token.pos_ in ['ADJ'] and token.text in category_name:
                    index.append(idx)
        category = df.iloc[index].drop_duplicates()
        # category.to_csv(f'{category_name[0]}.csv')
        ca_pos, ca_neg = self.num_polarity(category)
        return category, ca_pos, ca_neg

    def get_top(self,df):
        toppos = df[df['polarity']==1].sort_values(by='score')[-1:-11:-1].reset_index().review
        topneg = df[df['polarity']==0].sort_values(by='score',)[0:10].reset_index().review
        return toppos, topneg

    def get_report_data(self,type,main_df,tag):
        try:
            _df, _pos, _neg = self.to_category(main_df, tag)
            _score = (_pos/(_pos+_neg))*10
            _top_pos, _top_neg = self.get_top(_df)
        
            return _score,_pos,_neg,_top_pos,_top_neg
        except Exception as e:
            print(e)
            return 5.0,0,0,pd.DataFrame(columns=['temp']),pd.DataFrame(columns=['temp'])

    def process(self,data,res_name):
        main, main_pos, main_neg = self.sent2score(data)

        # get all the score and generate the overall summary
        overall_score = (main_pos/(main_pos + main_neg))*10

        food_score,food_pos,food_neg,food_top_pos,food_top_neg = \
          self.get_report_data('food',main,self.food_tag)
        service_score,service_pos,service_neg,service_top_pos,service_top_neg = \
          self.get_report_data('service',main,self.ser_tag)
        environment_score,environment_pos,environment_neg,environment_top_pos,environment_top_neg = \
          self.get_report_data('environment',main,self.env_tag)
        price_score,price_pos,price_neg,price_val,price_top_pos,price_top_neg,price_top_val = \
          self.to_category_price(main,10)


        df_categorysummary = pd.DataFrame({'name':['food','service','environment','price'],
                                  'score':[food_score,service_score,environment_score,price_score],
                                  'pos':[food_pos,service_pos,environment_pos,price_pos],
                                  'neg':[food_neg,service_neg,environment_neg,price_neg]})

        overall_summary = self.category_summary(df_categorysummary)


        # get the service report
        if not service_top_pos.empty or not service_top_pos.empty:
            service_report = {
                  'score':service_score,
                  'positive_num':service_pos,
                  'negative_num':service_neg,
                  'positive_reviews':service_top_pos[:10].tolist(),
                  'negative_reviews':service_top_neg[:10].tolist()
            }
        else:
            service_report = {
                  'score':service_score,
                  'positive_num':service_pos,
                  'negative_num':service_neg,
                  'positive_reviews':None,
                  'negative_reviews':None
            }
        # get the enviroment report
        if not environment_top_pos.empty or not environment_top_neg.empty:
            environment_report = {
                  'score':environment_score,
                  'positive_num':environment_pos,
                  'negative_num':environment_neg,
                  'positive_reviews':environment_top_pos[:10].tolist(),
                  'negative_reviews':environment_top_neg[:10].tolist()
            }
        else:
            environment_report = {
                  'score':environment_score,
                  'positive_num':environment_pos,
                  'negative_num':environment_neg,
                  'positive_reviews':None,
                  'negative_reviews':None
            }

        # get the price report
        price_report = {
              'score':environment_score,
              'positive_num':price_pos,
              'negative_num':price_neg,
              'valuation_num':price_val,
              'positive_reviews':price_top_pos.tolist(),
              'negative_reviews':price_top_neg.tolist(),
              'valuation_reviews':price_top_val.tolist()
        }

        # get the food report
        food_report, df_foodsummary = \
          self.get_food(main,res_name)
        food_report = {
          'reports':food_report,
          'food_summary':self.food_summary(df_foodsummary)
        }
        return overall_score,overall_summary,food_report,service_report,price_report,environment_report


class Process(object):
  
  def __init__(self):
    self.sap = SentimentProcessor()

  def sa_process(self,df,res_name):
    df['review'] = df['review'].str.lower()
    
    # overall_score,food_report,service_report,price_report,environment_report = self.sap.process(df)
    # print('overall_score')
    # print(overall_score)
    # print('service report')
    # print(service_report)
    # print('price report')
    # print(price_report)
    # print(' report')
    # print(environment_report)

    return self.sap.process(df,res_name)
