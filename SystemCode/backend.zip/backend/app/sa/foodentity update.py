#  get food entity dashboard 
def get_top(df):
  toppos = df[df['polarity']==1].sort_values(by='score')[-1:-11:-1].reset_index().review
  topneg = df[df['polarity']==0].sort_values(by='score',)[0:10].reset_index().review
    # set position
  print(topneg[:10])
  return toppos, topneg


def get_food(main, res_name):

  # load data
  res_food = pd.read_excel('RelData.xlsx',sheet_name='res_food')
  # get food list 
  food_graph = res_food[res_food['name1']==res_name]['name2'].tolist()
  from spacy.matcher import PhraseMatcher
  nlp_food = spacy.load('en_core_web_sm')
  matcher = PhraseMatcher(nlp_food.vocab, attr="LOWER")
  patterns = [nlp_food.make_doc(name) for name in food_graph]
  matcher.add("Names", None, *patterns)
  index = list()
  food_entity = list()
  for idx, val in enumerate(main['review']):
    doc = nlp_food(val)
    for match_id, start, end in matcher(doc):
        index.append(idx)
        food_entity.append(doc[start:end])
        df = pd.DataFrame({'index':index,'food_entity':food_entity})
  # get top 4 food
  df['food_entity'] = df['food_entity'].astype(str) 

  # try four food 
  food_name = df['food_entity'].value_counts()[:4].index.tolist()
  print(food_name)

  if len(food_name)==4:
    
    print(df['food_entity'].value_counts())
    index1 = df[df['food_entity']==food_name[0]]['index']
    index2 = df[df['food_entity']==food_name[1]]['index']
    index3 = df[df['food_entity']==food_name[2]]['index']
    index4 = df[df['food_entity']==food_name[3]]['index']
    df1 = main.iloc[index1,:].drop_duplicates()
    df2 = main.iloc[index2,:].drop_duplicates()
    df3 = main.iloc[index3,:].drop_duplicates()
    df4 = main.iloc[index4,:].drop_duplicates()
    pos1 = sum(df1['polarity'])
    neg1 = len(df1['polarity']) - pos1
    pos2 = sum(df2['polarity'])
    neg2 = len(df2['polarity']) - pos2
    pos3 = sum(df3['polarity'])
    neg3 = len(df3['polarity']) - pos3
    pos4 = sum(df4['polarity'])
    neg4 = len(df4['polarity']) - pos4
    score1 = round((pos1/(pos1+neg1))*10,2)
    score2 = round((pos2/(pos2+neg2))*10,2)
    score3 = round((pos3/(pos3+neg3))*10,2)
    score4 = round((pos4/(pos4+neg4))*10,2)
    df_foodsummary = pd.DataFrame({'name':[food_name[0],
                                           food_name[1],
                                           food_name[2],
                                           food_name[3]],
                          'score':[score1,score2,score3,score4],
                          'pos':[pos1,pos2,pos3,pos4],
                          'neg':[neg1,neg2,neg3,neg4]})

    food1_top_pos, food1_top_neg = get_top(df1)
    food1_report = {
          'entity':food_name[0],
          'score':score1,
          'positive_num':pos1,
          'negative_num':neg1,
          'positive_reviews':food1_top_pos[:10].tolist(),
          'negative_reviews':food1_top_neg[:10].tolist()
    }

    food2_top_pos, food2_top_neg = get_top(df2)
    food2_report = {
          'entity':food_name[1],
          'score':score2,
          'positive_num':pos2,
          'negative_num':neg2,
          'positive_reviews':food2_top_pos[:10].tolist(),
          'negative_reviews':food2_top_neg[:10].tolist()
    }

    food3_top_pos, food3_top_neg = get_top(df3)
    food3_report = {
          'entity':food_name[2],
          'score':score3,
          'positive_num':pos3,
          'negative_num':neg3,
          'positive_reviews':food3_top_pos[:10].tolist(),
          'negative_reviews':food3_top_neg[:10].tolist()
    }

    food4_top_pos, food4_top_neg = get_top(df4)
    food4_report = {
          'entity':food_name[3],
          'score':score4,
          'positive_num':pos4,
          'negative_num':neg4,
          'positive_reviews':food4_top_pos[:10].tolist(),
          'negative_reviews':food4_top_neg[:10].tolist()
    }

    foods_report = [food1_report,
                    food2_report,
                    food3_report,
                    food4_report]

    return foods_report, df_foodsummary

  elif  len(food_name)==3:

      index1 = df[df['food_entity']==food_name[0]]['index']
      index2 = df[df['food_entity']==food_name[1]]['index']
      index3 = df[df['food_entity']==food_name[2]]['index']
      df1 = main.iloc[index1,:].drop_duplicates()
      df2 = main.iloc[index2,:].drop_duplicates()
      df3 = main.iloc[index3,:].drop_duplicates()
      pos1 = sum(df1['polarity'])
      neg1 = len(df1['polarity']) - pos1
      pos2 = sum(df2['polarity'])
      neg2 = len(df2['polarity']) - pos2
      pos3 = sum(df3['polarity'])
      neg3 = len(df3['polarity']) - pos3
      score1 = round((pos1/(pos1+neg1))*10,2)
      score2 = round((pos2/(pos2+neg2))*10,2)
      score3 = round((pos3/(pos3+neg3))*10,2)

      df_foodsummary = pd.DataFrame({'name':[food_name[0],
                                             food_name[1],
                                             food_name[2]],
                            'score':[score1,score2,score3],
                            'pos':[pos1,pos2,pos3],
                            'neg':[neg1,neg2,neg3]})
      
      food1_top_pos, food1_top_neg = get_top(df1)
      food1_report = {
            'entity':food_name[0],
            'score':score1,
            'positive_num':pos1,
            'negative_num':neg1,
            'positive_reviews':food1_top_pos[:10].tolist(),
            'negative_reviews':food1_top_neg[:10].tolist()
      }

      food2_top_pos, food2_top_neg = get_top(df2)
      food2_report = {
            'entity':food_name[1],
            'score':score2,
            'positive_num':pos2,
            'negative_num':neg2,
            'positive_reviews':food2_top_pos[:10].tolist(),
            'negative_reviews':food2_top_neg[:10].tolist()
      }

      food3_top_pos, food3_top_neg = get_top(df3)
      food3_report = {
            'entity':food_name[2],
            'score':score3,
            'positive_num':pos3,
            'negative_num':neg3,
            'positive_reviews':food3_top_pos[:10].tolist(),
            'negative_reviews':food3_top_neg[:10].tolist()
      }


      foods_report = [food1_report,
                      food2_report,
                      food3_report]

      return foods_report, df_foodsummary

  elif len(food_name)==2:

      index1 = df[df['food_entity']==food_name[0]]['index']
      index2 = df[df['food_entity']==food_name[1]]['index']
      df1 = main.iloc[index1,:].drop_duplicates()
      df2 = main.iloc[index2,:].drop_duplicates()
      pos1 = sum(df1['polarity'])
      neg1 = len(df1['polarity']) - pos1
      pos2 = sum(df2['polarity'])
      neg2 = len(df2['polarity']) - pos2
      score1 = round((pos1/(pos1+neg1))*10,2)
      score2 = round((pos2/(pos2+neg2))*10,2)
      df_foodsummary = pd.DataFrame({'name':[food_name[0],
                                              food_name[1]],
                            'score':[score1,score2],
                            'pos':[pos1,pos2],
                            'neg':[neg1,neg2]})
      
      food1_top_pos, food1_top_neg = get_top(df1)
      food1_report = {
            'entity':food_name[0],
            'score':score1,
            'positive_num':pos1,
            'negative_num':neg1,
            'positive_reviews':food1_top_pos[:10].tolist(),
            'negative_reviews':food1_top_neg[:10].tolist()
      }

      food2_top_pos, food2_top_neg = get_top(df2)
      food2_report = {
            'entity':food_name[1],
            'score':score2,
            'positive_num':pos2,
            'negative_num':neg2,
            'positive_reviews':food2_top_pos[:10].tolist(),
            'negative_reviews':food2_top_neg[:10].tolist()
      }

      foods_report = [food1_report,
                      food2_report]

      return foods_report, df_foodsummary

  else:
      print('find only one food entity')
      return None

res_name = 'Colony' # input
foods_report, df_foodsummary = get_food(main, res_name)