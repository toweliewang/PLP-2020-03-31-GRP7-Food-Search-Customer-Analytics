> 敬请期待

<!-- # [](https://github.com/PedroGao/lin-cms-flask-starter/releases/tag/0.0.1-alpha.1) (2019-01-15)

## [1.2.5](https://github.com/PedroGao/lin-cms-flask-starter/releases/tag/0.0.1-alpha.1) (2019-01-15)

### 发布`0.0.1-alpha.1` -->

<!-- <a name="1.2.5"></a>

## [1.2.5](https://github.com/NervJS/taro/compare/v1.2.4...v1.2.5) (2019-01-14)

### Bug Fixes

- **cli:** h5 端编译对于带有后缀的资源引用编译错误 ([a96c994](https://github.com/NervJS/taro/commit/a96c994))

### Features

- **cli:** config 配置 alias 选项 暂不支持转换 usingComponents [#1704](https://github.com/NervJS/taro/issues/1704) ([#1859](https://github.com/NervJS/taro/issues/1859)) ([e3a5548](https://github.com/NervJS/taro/commit/e3a5548)) -->
