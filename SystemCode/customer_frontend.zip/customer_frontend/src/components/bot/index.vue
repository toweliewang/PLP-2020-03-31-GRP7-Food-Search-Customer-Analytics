<template>
  <div>
    <div v-if="isChatOpen" class="chat-window">
      <ChatBot ref="drawerCount" />
    </div>
    <LaunchButton :open="openChat" :close="closeChat" :is-open="isChatOpen" style="z-index:9999;" />
  </div>
</template>

<script>
import LaunchButton from './components/LaunchButton'
import ChatBot from './components/chatbot'

export default {
  name: 'Bot',
  components: { LaunchButton, ChatBot },
  inject: ['eventBus'],
  props: {
    // serviceName: {
    //   type: String,
    //   required: true,
    // },
    // closeTieSessionOnExit: {
    //   type: String,
    //   required: false,
    // },
  },
  data() {
    return {
      titleImageUrl: 'https://a.slack-edge.com/66f9/img/avatars-teams/ava_0001-34.png',
      isChatOpen: false,
      hasfeedback: false,
      hasrecommendation: false
    }
  },
  mounted() {
    this.eventBus.$on('feedback', (type) => {
      if (type == 'recommendation') {
        this.hasrecommendation = true
      } else {
        this.hasfeedback = true
      }
    })
    this.eventBus.$on('get_feedback', () => {
      this.isChatOpen = true
      setTimeout(() => {
        this.$refs.drawerCount.send_feedback_request()
        this.eventBus.$emit('checked_feedback')
      }, 100)
    })
  },
  methods: {
    openChat() {
      this.isChatOpen = true
      if (this.hasfeedback) {
        setTimeout(() => {
          this.$refs.drawerCount.send_feedback_request('feedback')
          this.eventBus.$emit('checked_feedback')
        }, 100)
      }
      if (this.hasrecommendation) {
        setTimeout(() => {
          this.$refs.drawerCount.send_feedback_request('recommendation')
          this.eventBus.$emit('checked_feedback')
        }, 100)
      }
    },
    closeChat() {
      this.isChatOpen = false
      this.hasfeedback = false
      localStorage.removeItem('message_history')
      //   if (this.closeTieSessionOnExit === 'true') {
      //     this.$teneoApi.closeSession();
      //   }
    }
  }
}
</script>
<style scope>
.chat-window {
  z-index:9999;
  font-family: 'Helvetica Neue', Helvetica, Arial, sans-serif;
  width: 370px;
  position: fixed;
  right: 25px;
  bottom: 100px;
  box-sizing: border-box;
  box-shadow: 0 2px 10px 0 rgba(0, 0, 0, 0.15);
  background: white;
  display: flex;
  flex-direction: column;
  justify-content: space-between;
  transition: 0.3s ease-in-out;
  border-radius: 10px;
}

@media (max-width: 450px) {
  .chat-window {
    width: 100%;
    height: 100%;
    max-height: 100%;
    right: 0px;
    bottom: 0px;
    border-radius: 0px;
  }
}
</style>
