<template>
  <div class="app-head">
    <img class="app-icon" src="@/assets/imgs/bot_logo.png" :alt="app.displayName">
    <div class="app-info">
      <div class="app-name">Food </div>
      <div class="app-name">Connoisseur Bot</div>
    <!-- <div class="app-poweredby">
        {{ app.displayName }} Built with
        <a target="_blank" aria-hidden="true">Food Bot</a>
      </div> -->
    </div>
    <slot />
  </div>
</template>

<style lang="scss" scoped>
.app-head {
  z-index: 999;
  padding: 16px;
  max-width: 450px;
  text-align: left;
  display: flex;
  background-color: #4e8cff;

  .app-icon {
    width: 45px;
    height: 45px;
    object-fit: cover;
    margin-top: 0px;
    margin-bottom: -5px;
    padding: 8px 8px 8px 8px;
    background-color: rgba(204, 204, 204, 0.25);
    border-radius: 50%;
    box-shadow: 0px 0px 6px 0px #203e74;
  }

  .app-info {
    padding: 5px 0px;
    margin-top:-2px;
    margin-left: 10px;
    height: 100%;

    .app-name {
      text-shadow: 0px 0px 6px #203e74;
      line-height: 19px;
      font-size: 18px;
      font-weight: bolder;
      color: #fff;
    }

    .app-poweredby {
      color: #5f6368;
      font-size: 14px;

      a[href] {
        color: #202124;
        text-decoration: none;
      }
    }
  }
}

.audio-toggle {
  display: flex;
  position: absolute;
  top: 0;
  right: 45px;
  margin: 20px 0px;
  z-index: 999;
  padding: 8px 8px 8px 8px;
  background-color: rgba(204, 204, 204, 0.25);
  border-radius: 50%;
  cursor: pointer;
  color: inherit;
  transition: padding 0.25s ease;
  @media screen and (min-width: 720px) {
    right: 0;
  }
  i {
    padding: 1px;
  }
}

.close-toggle {
  display: flex;
  position: absolute;
  top: 0;
  right: 5px;
  margin: 20px 0px;
  z-index: 999;
  padding: 8px 8px 8px 8px;
  background-color: rgba(204, 204, 204, 0.25);
  border-radius: 50%;
  border-radius: 20px 20px;
  cursor: pointer;
  color: white;
  transition: padding 0.25s ease;

  @media screen and (min-width: 720px) {
    display: none;
  }
  i {
    padding: 1px;
  }
}
</style>

<script>
export default {
  name: 'TopHead',
  props: {
    app: {
      type: Object,
      default: null
    }
  }
}
</script>
