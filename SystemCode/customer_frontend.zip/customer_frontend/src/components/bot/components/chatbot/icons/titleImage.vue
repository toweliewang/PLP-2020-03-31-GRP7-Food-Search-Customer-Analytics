<!-- eslint-disable vue/html-indent -->
<template>
  <svg
    id="Layer_1"
    version="1.1"
    xmlns="http://www.w3.org/2000/svg"
    xmlns:xlink="http://www.w3.org/1999/xlink"
    x="0px"
    y="0px"
    viewBox="0 0 100 100"
    style="enable-background:new 0 0 100 100;"
    xml:space="preserve"
  >
    <rect style="fill:#FF4C5B;" width="100" height="100" />
    <g>
      <rect
        x="0.1"
        y="74.1"
        transform="matrix(0.7071 -0.7071 0.7071 0.7071 -30.1665 95.4559)"
        style="fill:#2F286E;"
        width="200"
        height="20"
      />
    </g>
    <rect
      x="-32.9"
      y="-14.6"
      transform="matrix(0.7071 -0.7071 0.7071 0.7071 -58.2315 30.2746)"
      style="fill:#FEC800;"
      width="80.6"
      height="200"
    />
    <g>
      <rect
        x="6.1"
        y="33.6"
        transform="matrix(0.7071 -0.7071 0.7071 0.7071 -22.0457 97.0638)"
        style="fill:#2F286E;"
        width="200"
        height="83"
      />
    </g>
  </svg>
</template>
