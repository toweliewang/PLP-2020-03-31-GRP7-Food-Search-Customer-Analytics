<template>
  <div>
    <slot name="nav" />
    <slot name="content" />
  </div>
</template>
