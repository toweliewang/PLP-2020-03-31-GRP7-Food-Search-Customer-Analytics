import { get, post } from '@/utils/axios'

// 我们通过 class 这样的语法糖使模型这个概念更加具象化，其优点：耦合性低、可维护性。
class Eatery {
  async getEatery(eid) {
    const res = await get('v1/eatery/' + eid)
    return res
  }
  async getEateries() {
    const res = await get('v1/eatery/list')
    return res
  }
  async getEateriesbyu_id(uid) {
    const res = await get('v1/eatery/list/' + uid)
    return res
  }
  async getEateriesbyname_all(name) {
    const res = await get('v1/eatery/search', {
      q: name
    })
    return res
  }
  async getEateriesbycuisine_all(cuisine) {
    const res = await get('v1/eatery/searchcuisine_all', {
      q: cuisine
    })
    return res
  }
  async getEateries_simple_search() {
    const res = await get('v1/eatery/simplesearch')
    return res
  }
  async getEateries_simple_search_all() {
    const res = await get('v1/eatery/simplesearch/all')
    return res
  }
  async getallCuisine() {
    const res = await get('v1/eatery/getallcuisine')
    return res
  }
  async selectEatery(eid) {
    return post('v1/eatery/select', {
      eid: eid
    }, {
      handleError: true
    })
  }
  async getEateriesbycuisine(eid) {
    const res = await get('v1/eatery/searchbycuisine', {
      q: eid
    })
    return res
  }
}
export default new Eatery()
