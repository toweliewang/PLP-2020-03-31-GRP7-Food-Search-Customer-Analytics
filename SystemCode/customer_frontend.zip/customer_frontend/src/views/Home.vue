<template>
  <div><section class="section-hero section-shaped my-0">
    <div class="shape shape-style-1 shape-primary">
      <span class="span-150" />
      <span class="span-50" />
      <span class="span-50" />
      <span class="span-75" />
      <span class="span-100" />
      <span class="span-75" />
      <span class="span-50" />
      <span class="span-100" />
      <span class="span-50" />
      <span class="span-100" />
    </div>
    <div class="container shape-container d-flex align-items-center">
      <div class="col px-0">
        <div class="row justify-content-center align-items-center">
          <div class="col-lg-7 text-center pt-lg">
            <img src="@/assets/imgs/logo.png" style="width: 40%;" class="img-fluid">
            <p class="lead text-white mt-4 mb-5">Your perfect dining experience awaits...</p>
            <div class="btn-wrapper">
              <base-button
                @click="handleRegister()"
                class="mb-3 mb-sm-0"
                type="info"
                icon="ni ni-circle-08"
              >
                Register
              </base-button>
              <base-button
                class="mb-3 mb-sm-0"
                type="white"
                icon="ni ni-tag"
                @click="handleLogin()"
              >
                Login Now
              </base-button>
            </div>
          </div>
        </div>
        <div class="row align-items-center justify-content-around stars-and-coded">
          <div class="col-sm-4">
            <span class="text-white alpha-7 ml-3">Star us on</span>
            <a href="https://github.com/creativetimofficial/argon-design-system" target="_blank" title="Support us on Github">
              <img src="img/brand/github-white-slim.png" style="height: 22px; margin-top: -3px">
            </a>
          </div>
          <div class="col-sm-4 mt-4 mt-sm-0 text-right">
            <span class="text-white alpha-7">Coded by <b>PLP TEAM 7</b></span>
          </div>
        </div>
      </div>
    </div>
  </section>
  </div>
</template>
<script>

export default {
  name: 'Components',
  components: {
  },
  data() {
    return {

    }
  },
  methods: {
    handleLogin() {
      this.$router.push('/login')
    },
    handleRegister(){
      this.$router.push('/register')
    }
  }
}
</script>
