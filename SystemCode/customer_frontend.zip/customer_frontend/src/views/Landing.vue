<template>
  <div>

    <div class="position-relative">
      <el-backtop :bottom="100">
        <div
          style="{
        height: 100%;
        width: 100%;
        background-color: #f2f5f6;
        box-shadow: 0 0 6px rgba(0,0,0, .12);
        text-align: center;
        line-height: 40px;
        color: #1989fa;
      }"
        >
          UP
        </div>
      </el-backtop>
      <!-- shape Hero -->
      <section class="section-shaped my-0">
        <div class="shape shape-style-1 shape-default shape-skew">
          <span />
          <span />
          <span />
          <span />
          <span />
          <span />
          <span />
          <span />
          <span />
        </div>
        <div class="container shape-container d-flex">
          <div class="col px-0">
            <div class="row">
              <div class="col-lg-6">
                <h1 class="display-3  text-white">Looking for a place to dine?
                  <span>We are here to help!</span>
                </h1>
                <p class="lead  text-white">Click on the quick search button to search by restaurant or cuisine. Use the detail search for more specific search requirements.</p>
                <div class="btn-wrapper">
                  <base-button
                    class="mb-3 mb-sm-0"
                    type="info"
                    icon="ni ni-pin-3"
                    @click="showDetails('map')"
                  >
                    Quick Search
                  </base-button>
                  <base-button
                    class="mb-3 mb-sm-0"
                    type="white"
                    icon="ni ni-square-pin"
                    @click="showDetails('chatbot')"
                  >
                    Detail Search
                  </base-button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
      <!-- 1st Hero Variation -->
    </div>
    <section class="section bg-secondary map">
      <div class="container" style="display:flex;flex-direction:column;margin:0px;margin-left:220px;">
        <div class="card shadow" style="width:160%;display:inline-block;">
          <el-row style="width:100%;margin:0px auto;margin-left:10px;margin-top:20px;" :gutter="40">
            <el-col :span="2">
              <icon v-if="(form.search_cuisine == '' && form.search_name == '')" name="fa fa-search" size="md" type="primary" shadow rounded />
              <icon v-else name="fa fa-refresh" size="md" type="primary" shadow rounded style="cursor: pointer;" @click.native="refreshMap()" />
            </el-col>
            <el-col :span="18" :offset="4">
              <el-form :inline="true" :model="form" style="padding-top:5px;" label-width="150px">
                <el-form-item label="Restaurant">
                  <el-autocomplete v-model="form.search_name"
                                   placeholder="Restaurant Name"
                                   style="width: 200px;"
                                   clearable
                                   :fetch-suggestions="querySearch"
                                   :disabled="disable_input"
                                   @keyup.enter.native="handleSelect()"
                                   @focus="handleClickInput()"
                  />
                </el-form-item>
                <el-form-item label="Cuisine">
                  <el-select v-model="form.search_cuisine"
                             placeholder="Cuisine"
                             style="width: 200px;"
                             :disabled="disable_select"
                             @focus="handleClickSelect()"
                             @change="handleChange()"
                  >
                    <el-option v-for="(item,index) in search_cuisine" :key="index" :label="item" :value="item" />
                  </el-select></el-form-item>
              </el-form>
            </el-col>
          </el-row>

        </div>
        <el-row style="width:160%;margin-left:5px;" :gutter="30">
          <el-col :span="map_col_size">
            <div class="card bg-default shadow border-0" style="margin-top:35px;">
              <map-chart
                ref="mapchat"
                v-loading="loading"
                element-loading-text="Loading Map...."
                element-loading-spinner="el-icon-loading"
                element-loading-background="rgba(0, 0, 0, 0.8)"
                :searchform="form"
                @markerclick="handleMarkerClick"
                @markerclose="handleMarkerClose"
              />
            </div>
          </el-col>
          <el-col v-if="select_eatery.id !== undefined" :span="6">
            <el-card class="box-card eatery-card" shadow="hover">
              <div class="personal">
                <div class="personal-title">
                  <div style="float:left;">
                    Eatery Information
                  </div>
                </div>
                <el-divider />
                <div class="personal-influence">
                  <div class="personal-influence-item">
                    <div class="personal-influece-label">Name</div>
                    <div class="personal-influence-num color1">{{ select_eatery.name }}</div>
                  </div>
                </div>
                <div class="personal-influence">
                  <div class="personal-influence-item">
                    <div class="personal-influece-label">Owner</div>
                    <div class="personal-influence-num color1">{{ select_eatery.owner.name }}</div>
                  </div>
                </div>
                <div class="personal-influence">
                  <div class="personal-influence-item">
                    <div class="personal-influece-label">Cuisine</div>
                    <div class="personal-influence-num color1">{{ select_eatery.cuisine }}</div>
                  </div>
                </div>
                <div class="personal-influence">
                  <div class="personal-influence-item">
                    <div class="personal-influece-label">Phone</div>
                    <div class="personal-influence-num color1">{{ select_eatery.phone }}</div>
                  </div>
                </div>
                <div class="personal-influence" style="margin-bottom:15px;">
                  <div class="personal-influence-item">
                    <div class="personal-influece-label">Rating</div>
                    <el-rate
                      v-model="select_eatery.rating"
                      style="margin-top:10px;"
                      disabled
                      show-score
                      text-color="#ff9900"
                      score-template="{value}"
                    />
                  </div>
                </div>
                <el-divider />
                <div class="personal-influence" style="margin-bottom:15px;height:100px;">
                  <div class="personal-influence-item">
                    <div class="personal-influece-label">Address</div>
                    <div class="personal-influence-num longcontent color3">
                      <i class="el-icon-location-information" />
                      {{ select_eatery.address }}</div>
                    <div class="personal-influence-num longcontent">
                      <i class="el-icon-discover" />
                      {{ select_eatery.from_info }}</div>
                  </div>
                </div>
                <el-divider />
                <el-collapse v-model="activeName_eatery" accordion style="margin-top:-10px;">
                  <el-collapse-item name="1">
                    <template slot="title" style="text-align:left;">
                      Description
                    </template>
                    <div>
                      {{ select_eatery.description }}
                    </div>
                  </el-collapse-item>
                </el-collapse>
              </div>
            </el-card>
          </el-col>

        </el-row>

      </div>
    </section>
    <section class="section section-lg chatbot">
      <div class="container">
        <div class="row row-grid align-items-center">
          <div class="col-md-6 order-md-2">
            <img src="@/assets/imgs/graph.png" class="img-fluid floating">
          </div>
          <div class="col-md-6 order-md-1">
            <div class="pr-md-5">

              <h3>Chatbot Detail Search</h3>
              <p>The detail search can help you find restaurants by dish, preferred taste and accessibility based on distance to MRT stations.
                Click on the Chat Button at the bottom right to begin.</p>
              <ul class="list-unstyled mt-5">
                <li class="py-2">
                  <div class="d-flex align-items-center">
                    <badge type="success" circle class="mr-3" icon="ni ni-fat-add" />
                    <h6 class="mb-0">Fine-grained search by dishes and tastes</h6>
                  </div>
                </li>
                <li class="py-2">
                  <div class="d-flex align-items-center">
                    <badge type="success" circle class="mr-3" icon="ni ni-fat-add" />
                    <h6 class="mb-0">Find restaurants near to MRT stations</h6>
                  </div>
                </li>
                <li class="py-2">
                  <div class="d-flex align-items-center">
                    <badge type="success" circle class="mr-3" icon="ni ni-fat-add" />
                    <h6 class="mb-0">Super fast search, powered by food graph</h6>
                  </div>
                </li>
                <li class="py-2">
                  <div class="d-flex align-items-center">
                    <badge type="success" circle class="mr-3" icon="ni ni-fat-add" />
                    <h6 class="mb-0">Proactive recommendation and feedback solicitation</h6>
                  </div>
                </li>
                <li class="py-2">
                  <div class="d-flex align-items-center">
                    <badge type="success" circle class="mr-3" icon="ni ni-fat-add" />
                    <h6 class="mb-0">Self-learning through user interactions</h6>
                  </div>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </section>
  </div>
</template>

<script>
import MapChart from '@/components/chart/MapChart'
import Eatery from '@/api/eatery'
export default {
  name: 'Home',
  components: { MapChart },
  data() {
    return {
      form: {
        search_name: '',
        search_cuisine: ''
      },
      search_eateries: [],
      search_cuisine: [],
      disable_select: false,
      disable_input: false,
      select_eatery: {},
      map_col_size: 24,
      loading: true
    }
  },
  mounted() {
    this.load_fetch()
    setTimeout(() => {
      this.loading = false
    }, 4500)
  },
  methods: {
    search() {
      this.form.search_cuisine = ''
    },
    handleChange() {
      this.form.search_name = ''
    },
    handleClickInput() {
      this.form.search_cuisine = ''
    },
    handleClickSelect() {
      this.form.search_name = ''
    },
    handleSelect() {
      this.form.search_cuisine = ''
    },
    showDetails(type) {
      var el = document.getElementsByClassName(type)[0]
      console.log(el.offsetTop)
      this.$nextTick(function() {
        window.scrollTo({ 'behavior': 'smooth', 'top': el.offsetTop })
      })
    },
    async load_fetch() {
      try {
        const search_eateries = await Eatery.getEateries_simple_search_all()
        this.search_eateries = search_eateries
        console.log(this.search_eateries)
        const search_cuisines = await Eatery.getallCuisine()
        this.search_cuisine = search_cuisines.cuisines
        console.log(search_cuisines)
      } catch (error) {

      }
    },
    querySearch(queryString, cb) {
      var search_eateries = this.search_eateries
      var results = queryString ? search_eateries.filter(this.createFilter(queryString)) : search_eateries
      // 调用 callback 返回建议列表的数据
      console.log(results)
      cb(results)
    },
    createFilter(queryString) {
      return (search_eateries) => {
        return (search_eateries.value.toLowerCase().indexOf(queryString.toLowerCase()) === 0)
      }
    },
    handleMarkerClick(item) {
      this.select_eatery = item.target.content
      console.log(item.target.content)
      this.map_col_size = 18
    },
    handleMarkerClose() {
      // this.select_eatery = {}
      // this.map_col_size = 24
    },
    refreshMap() {
      this.select_eatery = {}
      this.form.search_name = ''
      this.form.search_cuisine = ''
      this.map_col_size = 24
      this.$refs.mapchat.refresh_map()
    }
  }
}
</script>
<style lang="scss" scoped>
.section /deep/ .el-card__body {
  padding-top: 20x;
  padding-bottom: 0px;
}
.section /deep/ .el-collapse {
  border-top: none;
  border-bottom: none;
  cursor: pointer;
  .el-collapse-item__header {
    border-bottom: none;
    color: #2f4e8c;
    padding-left: 10px;
  }

  .el-collapse-item__content {
    background: #e9f0f8;
    color: #2f4e8c;
    border-radius: 4px;
    padding: 10px 5px 10px 5px;
    margin-bottom: 20px;
  }
}
  .eatery-card{
    margin-top:180px;
    width:100%;
    .personal {
      height: 100%;
      margin-left: -10px;
      margin-top:-35px;
      .personal-title {
        margin: 30px 0 10px 5px;
        height: 24px;
        line-height: 22px;
        font-weight: bold;
        color: #1b5dd1;
        font-size: 16px;
      }
      .el-divider--horizontal {
    display: block;
    height: 1px;
    width: 100%;
    margin: 5px 0;
}
      .personal-avatar {
        width: 140px;
        height: 140px;
        margin: 0 auto 40px;
        border-radius: 75px;
        box-shadow: 0 0 30px 0 #cfd5e3;
      }
      .personal-info {
        margin: 0px 0px -5px -10px;
        .content{
          display: flex;
          justify-content: flex-start;
          .title{
          text-align: left;
          font-size: 15px;
          font-weight: bold;
          line-height: 20px;
        }
        .context{
          flex-grow:1;
          margin-left: 20px;
          text-align: left;
          font-size: 15px;
          font-weight: bold;
          line-height: 20px;
        }
        }
        }
              .personal-influence {
        display: flex;
        justify-content: left;
        padding: 10px 5px 0px 10px;
        .personal-influence-item {
          display: flex;
          flex-direction: column;
          align-items: left;
          .personal-influence-num {
            font-size: 16px;
            line-height: 28px;
            &.color1 {
              color: #00c292c4;
            }
            &.color2 {
              color: #fec108;
            }
            &.color3 {
              color: #03a9f3;
            }
            &.longcontent{
              margin-top:5px;
              font-size: 14px;
              line-height: 18px;
            }
          }
          .personal-influece-label {
            font-size: 16px;
            font-weight: 400;
            color: #87a4db;
            line-height: 17px;
          }
        }
      }
      .personal-tabs {
        margin-bottom: 20px;
      }
      .personal-tabs /deep/ .is-top {
        width: 320px;
        display: flex;
        justify-content: space-around;
      }
      .personal-tabs /deep/ .el-tabs__content {
        text-indent: 20px;
      }
      }
  }
</style>
