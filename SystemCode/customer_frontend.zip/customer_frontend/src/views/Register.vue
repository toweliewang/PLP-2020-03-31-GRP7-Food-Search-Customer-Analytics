<template>
  <section class="section section-shaped section-lg my-0">
    <div class="shape shape-style-1 bg-gradient-default">
      <span />
      <span />
      <span />
      <span />
      <span />
      <span />
      <span />
      <span />
    </div>
    <div class="container pt-lg-md">
      <div class="row justify-content-center">
        <div class="col-lg-5">
          <card
            type="secondary"
            shadow
            header-classes="bg-white pb-5"
            body-classes="px-lg-5 py-lg-5"
            class="border-0"
          >
            <template>
              <div class="text-center text-muted mb-4">
                <h4>
                  Register
                </h4>
                <h5 class="text-muted">
                  Food Connoisseur
                </h5>
                <el-divider />
                <el-form
                  ref="registerForm"
                  :model="form"
                  :rules="rules"
                  class="login-form"
                  autocomplete="on"
                  label-position="left"
                >

                  <el-form-item prop="username">
                    <span class="svg-container">
                      <i class="ni ni-circle-08" />
                    </span>
                    <el-input
                      ref="username"
                      v-model="form.username"
                      placeholder="Username"
                      name="username"
                      type="text"
                      tabindex="1"
                      autocomplete="off"
                    />
                  </el-form-item>

                  <el-tooltip v-model="capsTooltip" content="Caps lock is On" placement="right" manual>
                    <el-form-item prop="password">
                      <span class="svg-container">
                        <i class="ni ni-key-25" />
                      </span>
                      <el-input
                        :key="passwordType"
                        ref="password"
                        v-model="form.password"
                        :type="passwordType"
                        placeholder="Password"
                        name="password"
                        tabindex="2"
                        autocomplete="off"
                        @keyup.native="checkCapslock"
                        @blur="capsTooltip = false"
                      />
                    </el-form-item>
                  </el-tooltip>

                  <el-tooltip v-model="capsTooltip" content="Caps lock is On" placement="right" manual>
                    <el-form-item prop="confirm_password">
                      <span class="svg-container">
                        <i class="ni ni-key-25" />
                      </span>
                      <el-input
                        :key="passwordType"
                        ref="password"
                        v-model="form.confirm_password"
                        :type="passwordType"
                        placeholder="Confirm Password"
                        name="password"
                        tabindex="2"
                        autocomplete="off"
                        @keyup.native="checkCapslock"
                        @blur="capsTooltip = false"
                      />
                    </el-form-item>
                  </el-tooltip>

                  <el-form-item prop="email">
                    <span class="svg-container">
                      <i class="el-icon-message" />
                    </span>
                    <el-input
                      ref="email"
                      v-model="form.email"
                      type="text"
                      placeholder="Email"
                      name="email"
                      tabindex="2"
                      autocomplete="off"
                    />
                  </el-form-item>

                  <el-form-item prop="gender">
                    <span class="svg-container">
                      <i class="el-icon-info" />
                    </span>
                    <el-select v-model="form.gender" placeholder="Gender">
                      <el-option
                        v-for="item in gender_options"
                        :key="item.value"
                        :label="item.label"
                        :value="item.value"
                      />
                    </el-select>
                  </el-form-item>

                  <el-form-item prop="age">
                    <span class="svg-container">
                      <i class="el-icon-camera-solid" />
                    </span>
                    <el-input
                      ref="age"
                      v-model.number="form.age"
                      placeholder="Age"
                      name="age"
                      tabindex="2"
                    />
                  </el-form-item>

                  <el-form-item prop="phone">
                    <span class="svg-container">
                      <i class="el-icon-phone-outline" />
                    </span>
                    <el-input
                      ref="phone"
                      v-model.number="form.phone"
                      placeholder="Phone"
                      name="phone"
                      tabindex="2"
                    />
                  </el-form-item>

                  <div style="display:flex;">
                    <el-button
                      :loading="loading"
                      type="primary"
                      class="register-button"
                      @click.native.prevent="registercheck()"
                    >Register</el-button>
                  </div>

                </el-form>
              </div></template>
          </card>
        </div>
      </div>
    </div>
  </section>
</template>
<script>
import { mapActions, mapMutations } from 'vuex'
import User from '@/api/user'
import Utils from '@/utils/util'

export default {
  name: 'Login',
  components: {
  },
  data() {
    var checkAge = (rule, value, callback) => {
      if (!value) {
        return callback(new Error('Please enter your age'))
      }
      setTimeout(() => {
        if (!Number.isInteger(value)) {
          callback(new Error('Only Number'))
        } else {
          if (value < 18) {
            callback(new Error('18 or above'))
          } else {
            callback()
          }
        }
      }, 1000)
    }
    var validatePass = (rule, value, callback) => {
      if (value === '') {
        callback(new Error('Please enter the password'))
      } else {
        if (this.form.confirm_password !== '') {
          this.$refs.registerForm.validateField('checkPass')
        }
        callback()
      }
    }
    var validatePass2 = (rule, value, callback) => {
      if (value === '') {
        callback(new Error('Please enter the password again'))
      } else if (value !== this.form.password) {
        callback(new Error('The two passwords you entered did not match'))
      } else {
        callback()
      }
    }
    return {
      loading: false, // 加载动画
      wait: 2000, // 2000ms之内不能重复发起请求
      throttleLogin: null, // 节流登录
      form: {
        username: '',
        password: '',
        confirm_password: '',
        email: '',
        group_id: 2,
        phone_prepend: '',
        gender: '',
        phone: ''
      },
      passwordType: 'password',
      capsTooltip: false,
      gender_options: [{
        value: '0',
        label: 'Man'
      }, {
        value: '1',
        label: 'Woman'
      }],
      rules: {
        username: [
          { required: true, message: 'Please enter your username', trigger: 'blur' }
        ],
        password: [
          { validator: validatePass, trigger: 'blur' },
          { min: 6, max: 16, message: 'Min 6 charaters,Max 16 charaters.', trigger: 'blur' }
        ],
        email: [
          { required: true, type: 'email', message: 'Please enter your email(email format please)', trigger: ['blur', 'change'] }
        ],
        age: [
          { validator: checkAge, trigger: 'blur' }
        ],
        confirm_password: [
          { validator: validatePass2, trigger: 'blur' }
        ],
        phone: [
          { required: true, message: 'Please enter your phone', trigger: 'blur' }
        ]
      }
    }
  },
  created() {
    // 节流登录
    this.throttleLogin = Utils.throttle(this.login, this.wait)
  },
  methods: {
    async login() {
      const { username, password } = this.form
      try {
        this.loading = true
        await User.getToken(username, password)
        await this.getInformation()
        this.loading = false
        this.$router.push('/about')
        this.$message.success('登录成功')
      } catch (e) {
        this.loading = false
        console.log(e)
      }
    },
    back() {
      this.$router.push('/login')
    },
    async getInformation() {
      try {
        // 尝试获取当前用户信息
        const user = await User.getAuths()
        this.setUserAndState(user)
        this.setUserAuths(user.auths)
      } catch (e) {
        console.log(e)
      }
    },
    registercheck() {
      this.$refs['registerForm'].validate((valid) => {
        if (valid) {
          this.register()
        }
      })
    },
    async register() {
      const obj = {
        data: {
          username: this.form.username,
          password: this.form.password,
          group_id: this.form.group_id,
          confirm_password: this.form.confirm_password,
          email: this.form.email,
          gender: this.form.gender,
          phone: this.form.phone,
          age: this.form.age
        }
      }
      try {
        await User.register(obj.data)
        this.$message.success('Register Sucessfully')
        this.$router.push('/login')
      } catch (e) {
        console.log(e)
      }
    },
    ...mapActions(['setUserAndState']),
    ...mapMutations({
      setUserAuths: 'SET_USER_AUTHS'
    }),
    showPwd() {
      if (this.passwordType === 'password') {
        this.passwordType = ''
      } else {
        this.passwordType = 'password'
      }
      this.$nextTick(() => {
        this.$refs.password.focus()
      })
    }
  }
}
</script>
<style lang="scss">
/* 修复input 背景不协调 和光标变色 */
/* Detail see https://github.com/PanJiaChen/vue-element-admin/pull/927 */

$bg: #283443;
$light_gray: #fff;
$cursor: #283443;

@supports (-webkit-mask: none) and (not (cater-color: $cursor)) {
  .login-form .el-input input {
    color: $cursor;
  }
}

.register-button{
  width:100%;margin-bottom:30px;line-height:25px;
}

/* reset element-ui css */
.login-form {
  .el-input {
    display: inline-block;
    height: 25px;
    width: 85%;

    input::-webkit-input-placeholder{
            color:rgba(85, 83, 83, 0.616);
    }

    input {
      background: transparent;
      border: 0px;
      -webkit-appearance: none;
      border-radius: 0px;
      padding: 10px 5px 5px 10px;
      color: black;
      height: 25px;
      line-height: 25px;
      font-size: 16px;
      margin-left: 5px;
      caret-color: $cursor;

      &:-webkit-autofill {
        box-shadow: 0 0 0px 1000px $bg inset !important;
        -webkit-text-fill-color: $cursor !important;
      }
    }
  }
  .el-select{
    display: inline-block;
    width: 85%;

    .el-input {
      height:100%;
      margin-top: 5px;
      input {
      background: transparent;
      border: 0px;
      -webkit-appearance: none;
      border-radius: 0px;
      padding: 15px 5px 10px 0px;
      margin-left: 15px;
      color: black;
      height: 25px;
      line-height: 25px;
      font-size: 16px;
      caret-color: $cursor;
            &:-webkit-input-placeholder {
        color: #aab2bd;
        font-size: 12px;
    }

      &:-webkit-autofill {
        box-shadow: 0 0 0px 1000px $bg inset !important;
        -webkit-text-fill-color: $cursor !important;
      }
    }
    }
    .el-input__suffix{
      margin-right:-22px;
      margin-top: 0px;
    }
  }

  .el-form-item {
    border: 1px solid rgba(255, 255, 255, 0.1);
    background: rgba(0, 0, 0, 0.1);
    border-radius: 5px;
    color: #454545;
.el-form-item__content {
      margin: 5px auto;
      .el-form-item__error{
        right: 0;
        left: auto;
        margin: 3px auto;
        font-size: 14px;
      }
    }
  }
}
</style>

<style lang="scss" scoped>
$bg: #2d3a4b;
$dark_gray: #889aa4;
$light_orange: rgb(243, 157, 45);

i{
  font-size: 18px;
}
.login-container {
  height: 100%;
  width: 100%;
  background-size: auto;
  position: relative;

  .login-wrapper {
    top: 10%;

    .login-card {
      margin-top: 50px;
      border: 0px;
      background-color: #006699;

      .login-form {
        position: relative;
        width: 400px;
        max-width: 100%;
        padding: 50px 35px 0px 25px;
        margin: 0 auto;
        overflow: hidden;
      }

      .tips {
        font-size: 14px;
        color: #fff;
        margin-bottom: 10px;

        span {
          &:first-of-type {
            margin-right: 16px;
          }
        }
      }

      .svg-container {
        padding: 15px 5px 5px 20px;
        color: $dark_gray;
        vertical-align: middle;
        width: 30px;
        display: inline-block;
        font-size: 18px;
      }

      .title-container {
        position: relative;

        .title {
          font-size: 20px;
          color: $light_orange;
          margin: -20px auto 40px auto;
          text-align: center;
          font-weight: bold;
        }
        .sub-title {
          font-size: 18px;
          color: $light_orange;
          margin: 10px auto 25px auto;
          text-align: center;
          font-weight: bold;
        }

              .el-divider--horizontal {

    display: block;
    height: 1px;
    width: 100%;
    margin: -20px auto auto 0;
}
      }

      .show-pwd {
        float:right;
        font-size: 12px;
        color: $dark_gray;
        cursor: pointer;
        user-select: none;
      }
    }
  }
}
</style>
