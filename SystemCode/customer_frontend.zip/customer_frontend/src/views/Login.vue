<template>
  <section class="section section-shaped section-lg my-0">
    <div class="shape shape-style-1 bg-gradient-default">
      <span />
      <span />
      <span />
      <span />
      <span />
      <span />
      <span />
      <span />
    </div>
    <div class="container pt-lg-md">
      <div class="row justify-content-center">
        <div class="col-lg-5">
          <card
            type="secondary"
            shadow
            header-classes="bg-white pb-5"
            body-classes="px-lg-5 py-lg-5"
            class="border-0"
          >
            <template>
              <div class="text-center text-muted mb-4">
                <h4>
                  Login
                </h4>
                <h5 class="text-muted">
                  Food Connoisseur
                </h5>
              </div>
              <form role="form">
                <base-input
                  v-model="form.username"
                  alternative
                  class="mb-3"
                  placeholder="Username"
                  addon-left-icon="ni ni-email-83"
                />
                <base-input
                  v-model="form.password"
                  alternative
                  type="password"
                  placeholder="Password"
                  addon-left-icon="ni ni-lock-circle-open"
                />
                <div class="text-center">
                  <base-button type="primary" class="my-4" @click="login()">Login</base-button>
                </div>
              </form>
            </template>
          </card>
          <div class="row mt-3">
            <div class="col-12 text-right">
              <a href="#" class="text-light" @click="doRegister()">
                <small>Create new account</small>
              </a>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
</template>
<script>
import User from '@/api/user'
import { mapActions, mapMutations } from 'vuex'
import Utils from '@/utils/util'
export default {
  name: 'Login',
  components: {

  },
  data() {
    return {
      wait: 2000, // 2000ms之内不能重复发起请求
      throttleLogin: null, // 节流登录
      form: {
        username: '',
        password: ''
      }
    }
  },
  created() {
    // 节流登录
    this.throttleLogin = Utils.throttle(this.login, this.wait)
  },
  methods: {
    async login() {
      if (this.form.username === '') {
        this.$message.error('Please enter your username')
      } else {
        if (this.form.password === '') {
          this.$message.error('Please enter the password')
        }
      }
      if (this.form.password !== '' && this.form.username !== '') {
        const { username, password } = this.form
        try {
          this.loading = true
          await User.getToken(username, password)
          await this.getInformation()
          this.loading = false
          this.$router.push('/landing')
          this.$message.success('Login Successfully')
        } catch (e) {
          this.loading = false
          this.$message.error(e.data.msg)
          console.log(e)
        }
      }
    },
    async getInformation() {
      try {
        // 尝试获取当前用户信息
        const user = await User.getAuths()
        console.log(user)
        this.setUserAndState(user)
        this.setUserAuths(user.auths)
      } catch (e) {
        console.log(e)
      }
    },
    doRegister() {
      this.$router.push('/register')
    },
    async register() {
      const obj = {
        data: {
          username: this.username,
          password: this.password,
          confirm_password: this.confirm_password,
          email: this.email
        }
      }
      try {
        await User.register(obj)
        this.$message.success('注册成功！')
      } catch (e) {
        console.log(e)
      }
    },
    ...mapActions(['setUserAndState']),
    ...mapMutations({
      setUserAuths: 'SET_USER_AUTHS'
    }),
    showPwd() {
      if (this.passwordType === 'password') {
        this.passwordType = ''
      } else {
        this.passwordType = 'password'
      }
      this.$nextTick(() => {
        this.$refs.password.focus()
      })
    }
  }
}
</script>
<style lang="scss">
/* 修复input 背景不协调 和光标变色 */
/* Detail see https://github.com/PanJiaChen/vue-element-admin/pull/927 */

$bg: #283443;
$light_gray: #fff;
$cursor: #fff;

@supports (-webkit-mask: none) and (not (cater-color: $cursor)) {
  .login-form .el-input input {
    color: $cursor;
  }
}

/* reset element-ui css */
.login-form {
  .el-input {
    display: inline-block;
    height: 35px;
    width: 85%;

    input {
      background: transparent;
      border: 0px;
      -webkit-appearance: none;
      border-radius: 0px;
      padding: 15px 5px 5px 15px;
      color: $light_gray;
      height: 40px;
      line-height: 35px;
      font-size: 16px;
      caret-color: $cursor;

      &:-webkit-autofill {
        box-shadow: 0 0 0px 1000px $bg inset !important;
        -webkit-text-fill-color: $cursor !important;
      }
    }
  }

  .el-form-item {
    border: 1px solid rgba(255, 255, 255, 0.1);
    background: rgba(0, 0, 0, 0.1);
    border-radius: 5px;
    color: #454545;
    .el-form-item__content {
      margin: 5px auto;
    }
  }
}
</style>
<style>
</style>
