<template>
  <header class="header-global">
    <base-nav class="navbar-main" transparent type="" effect="light" expand>
      <router-link v-if="user == null" slot="brand" class="navbar-brand mr-lg-3" to="/">
        <img src="@/assets/imgs/logo.png" alt="logo" style="width:75%;height:80%;">
      </router-link>
      <router-link v-if="user !== null" slot="brand" class="navbar-brand mr-lg-3" to="/landing">
        <img src="@/assets/imgs/logo.png" alt="logo" style="width:75%;height:80%;">
      </router-link>

      <div slot="content-header" slot-scope="{closeMenu}" class="row">
        <div class="col-6 collapse-brand">
          <a href="https://demos.creative-tim.com/vue-argon-design-system/documentation/">
            <img src="img/brand/blue.png">
          </a>
        </div>
        <div class="col-6 collapse-close">
          <close-button @click="closeMenu" />
        </div>
      </div>

      <ul class="navbar-nav align-items-lg-center ml-lg-auto">
        <li v-if="feedback" class="nav-item d-none d-lg-block ml-lg-1">
          <base-button
            type="warning"
            class="mb-3 mb-sm-0"
            icon="ni ni-email-83"
            @click="get_feedback()"
          />
        </li>
        <!-- <li v-if="user == null" class="nav-item d-none d-lg-block ml-lg-4">
          <base-button
            class="mb-3 mb-sm-0"
            type="white"
            icon="fa fa-sign-out mr-2"
            @click="handleLogin()"
          >
            login
          </base-button>
        </li> -->
        <li v-if="user !== null" class="nav-item d-none d-lg-block ml-lg-4">
          <base-dropdown>
            <base-button slot="title" type="primary" class="dropdown-toggle" icon="fa fa-user-circle-o">
              {{ user.username }}
            </base-button>
            <a class="dropdown-item" href="#" @click="handleClickProfile()"><i class="ni ni-archive-2" />Profile</a>
            <div class="dropdown-divider" />
            <a class="dropdown-item" href="#" @click="handleLogout()"><i class="ni ni-button-power" />Logout</a>
          </base-dropdown>
        </li>
      </ul>
    </base-nav>
  </header>
</template>
<script>
import BaseNav from '@/components/BaseNav'
import BaseDropdown from '@/components/BaseDropdown'
import CloseButton from '@/components/CloseButton'
import { mapGetters, mapActions } from 'vuex'
import Chatbot from '@/api/chatbot'

export default {
  components: {
    BaseNav,
    CloseButton,
    BaseDropdown
  },
  data() {
    return {
      feedback: false
    }
  },
  inject: ['eventBus'],
  computed: {
    ...mapGetters(['user'])
  },
  created() {
    if (this.user) {
      this.checkFeedback()
      this.checkRecommendation()
    }
  },
  mounted() {
    this.eventBus.$on('checked_feedback', () => {
      this.feedback = false
    })
  },
  methods: {
    ...mapActions(['loginOut', 'setUserAndState']),
    handleLogout() {
      this.loginOut()
      this.$router.push('/')
      window.location.reload(true)
    },
    handleLogin() {
      this.$router.push('/login')
    },
    handleClickProfile() {
      this.$router.push('/profile')
    },
    get_feedback() {
      this.feedback = false
      this.eventBus.$emit('get_feedback')
    },
    async checkFeedback() {
      const feedback = await Chatbot.check_feedback()
      if (feedback.status === 1) {
        this.feedback = true
        this.eventBus.$emit('feedback', 'feedback')
      } else {
        this.feedback = false
      }
    },
    async checkRecommendation() {
      const feedback = await Chatbot.check_recommendation()
      if (feedback.status === 1) {
        this.feedback = true
        this.eventBus.$emit('feedback', 'recommendation')
      } else {
        this.feedback = false
      }
    }
  }
}
</script>
<style>
</style>
