<template>
  <div id="app">
    <router-view name="header" />
    <main>
      <fade-transition origin="center" mode="out-in" :duration="250">
        <router-view />
      </fade-transition>
    </main>
    <!-- <router-view name="footer" /> -->
    <Bot v-if="user" />
  </div>
</template>
<script>
import { FadeTransition } from 'vue2-transitions'
import { mapActions, mapGetters } from 'vuex'
import Vue from 'vue'
import Bot from '@/components/bot'

export default {
  components: { Bot, FadeTransition },
  data() {
    return {
      timer: null,
      eventBus: new Vue()
    }
  },
  computed: {
    ...mapGetters(['user'])
  },
  mounted() {
    document.getElementById('loader').style.display = 'none'
  },
  provide() {
    // eventBus挂载的事件： addGroup addUser
    return {
      eventBus: this.eventBus
    }
  },
  methods: {
    ...mapActions(['loginOut'])
  }
}
</script>
