const Config = {
  baseURL: 'http://localhost:5000/',
  stagnateTime: 1 * 60 * 60 * 1000, // 无操作停滞时间  默认1小时
  openAutoJumpOut: true, // 是否开启无操作跳出
  notLoginRoute: ['login', 'register', 'home'] // 无需登录即可访问的路由 name,
}

export default Config
